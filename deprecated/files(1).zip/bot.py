"""
Scripture Bot for Discord
Supports: KJV + Apocrypha, LDS Standard Works, Brenton Septuagint,
          R.H. Charles' Book of Enoch & Book of Jubilees,
          Apostolic Fathers (J.B. Lightfoot)
"""

import re
import os
import random
import discord
from discord.ext import commands
from discord import app_commands
from scripture_lookup import ScriptureLookup, get_verse_drb, DRB_SUFFIXES, BIBLE_OT, BIBLE_NT, BIBLE_APOCRYPHA

# Load .env file if present
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv not installed, fall back to environment variable

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)
lookup = ScriptureLookup()

# ── Auto-detection regex ───────────────────────────────────────────────────────
# Scans ordinary messages for anything that looks like a scripture reference.
# Matches:  Gen 2:22  /  1 Nephi 3:7  /  D&C 76:22  /  Enoch 1:9  /  Herm 4:1-3
# The book part allows letters, digits, spaces, & ' - so abbreviations all work.
# We require a chapter:verse (the colon is mandatory) to avoid false positives
# on things like "Acts 2" or "John 3" which are too common as plain English.

_AUTO_RE = re.compile(
    r"(?<!\w)"                                     # not preceded by a word char
    r"((?:\d\s*)?[A-Za-z][A-Za-z&'\-\s]{0,28}?)"  # book name / abbreviation
    r"\s+(\d{1,3})"                                # chapter
    r":(\d{1,3})"                                  # :verse  (colon required)
    r"(?:\s*[-–]\s*(\d{1,3}))?"                    # optional -endverse
    r"(?!\w)"                                      # not followed by a word char
)


# ── Slash commands ─────────────────────────────────────────────────────────────

@bot.tree.command(name="verse", description="Look up a scripture verse")
@app_commands.describe(reference="e.g. John 3:16 | John 3:16 DRB | 2 Nephi 2:25 | Quran 2:255")
async def verse_slash(interaction: discord.Interaction, reference: str):
    parts = reference.rsplit(None, 1)
    if len(parts) == 2 and parts[1].lower() in DRB_SUFFIXES:
        result = get_verse_drb(parts[0].strip())
    else:
        result = lookup.get_verse(reference)
    await _send_result(interaction, result)

@bot.tree.command(name="ccc", description="Look up a paragraph of the Catechism of the Catholic Church")
@app_commands.describe(number="Paragraph number (1–2865)")
async def ccc_slash(interaction: discord.Interaction, number: int):
    await interaction.response.defer()
    data = _load_ccc()
    if data is None:
        await interaction.followup.send("⚠️ catechism.json not found."); return
    text = data.get(number)
    if text is None:
        await interaction.followup.send(f"⚠️ Paragraph {number} not found."); return
    text = re.sub(r'\*+', '', text)
    if len(text) > 4000: text = text[:3997] + "…"
    embed = discord.Embed(title=f"CCC {number}", description=text, color=discord.Color.gold())
    embed.set_footer(text="Catechism of the Catholic Church")
    await interaction.followup.send(embed=embed)

@bot.tree.command(name="canon", description="Look up a canon of the Code of Canon Law")
@app_commands.describe(number="Canon number (1–1751)")
async def canon_slash(interaction: discord.Interaction, number: int):
    await interaction.response.defer()
    data = _load_canon()
    if data is None:
        await interaction.followup.send("⚠️ canon.json not found."); return
    text = data.get(number)
    if text is None:
        await interaction.followup.send(f"⚠️ Canon {number} not found."); return
    text = re.sub(r'\*+', '', text)
    if len(text) > 4000: text = text[:3997] + "…"
    embed = discord.Embed(title=f"Canon {number}", description=text, color=discord.Color.dark_red())
    embed.set_footer(text="Code of Canon Law (1983)")
    await interaction.followup.send(embed=embed)

@bot.tree.command(name="catena", description="Patristic commentary on a Bible verse from catenabible.com")
@app_commands.describe(reference="e.g. John 3:16 | Romans 8:28 | Matthew 5:3")
async def catena_slash(interaction: discord.Interaction, reference: str):
    await interaction.response.defer()
    ctx = await bot.get_context(interaction)
    await cmd_catena(ctx, reference=reference)

@bot.tree.command(name="gematria", description="Look up gematria values for a word or number")
@app_commands.describe(query="Word, phrase, or number to look up")
async def gematria_slash(interaction: discord.Interaction, query: str):
    await interaction.response.defer()
    ctx = await bot.get_context(interaction)
    await cmd_gematria(ctx, query=query)

@bot.tree.command(name="votd", description="Verse of the Day in KJV")
async def votd_slash(interaction: discord.Interaction):
    await interaction.response.defer()
    ctx = await bot.get_context(interaction)
    await cmd_votd(ctx)

@bot.tree.command(name="delphi", description="Random Delphic maxim")
async def delphi_slash(interaction: discord.Interaction):
    await interaction.response.defer()
    ctx = await bot.get_context(interaction)
    await cmd_delphi(ctx)

@bot.tree.command(name="oracle", description="Random verse from an oracular corpus")
@app_commands.describe(question="Optional question for the oracle")
async def oracle_slash(interaction: discord.Interaction, question: str = ""):
    await interaction.response.defer()
    ctx = await bot.get_context(interaction)
    await cmd_oracle(ctx, question=question)

@bot.tree.command(name="homer", description="Roll three dice and receive a Homeric oracle")
@app_commands.describe(question="Optional question for the oracle")
async def homer_slash(interaction: discord.Interaction, question: str = ""):
    await interaction.response.defer()
    ctx = await bot.get_context(interaction)
    await cmd_homer(ctx, question=question)

@bot.tree.command(name="books", description="List available scripture collections")
@app_commands.describe(section="Optional section name to expand")
async def books_slash(interaction: discord.Interaction, section: str = ""):
    await interaction.response.defer()
    ctx = await bot.get_context(interaction)
    await list_books(ctx, section=section)


# ── Prefix command  !verse ─────────────────────────────────────────────────────

@bot.command(name="verse", aliases=["v", "scripture"])
async def verse_prefix(ctx, *, reference: str = ""):
    ref = reference.strip()

    # No reference — fully random verse
    if not ref:
        result = lookup.random_verse()
        await _send_result(ctx, result)
        return

    # ── Bible shortcuts ───────────────────────────────────────────────────────
    ref_lc = ref.lower()
    if ref_lc.startswith("bible"):
        sub = ref_lc[5:].strip()
        if sub in ("ot", "old testament", "old"):
            result = lookup.random_verse_from_books(BIBLE_OT)
            await _send_result(ctx, result)
        elif sub in ("nt", "new testament", "new"):
            result = lookup.random_verse_from_books(BIBLE_NT)
            await _send_result(ctx, result)
        elif sub in ("apocrypha", "apoc", "deuterocanon", "deuterocanonical"):
            result = lookup.random_verse_from_books(BIBLE_APOCRYPHA)
            await _send_result(ctx, result)
        elif sub in ("otnt", "ot nt", "nt ot"):
            # Return one from OT and one from NT
            r1 = lookup.random_verse_from_books(BIBLE_OT)
            r2 = lookup.random_verse_from_books(BIBLE_NT)
            await _send_result(ctx, r1)
            await _send_result(ctx, r2)
        else:
            # Just "Bible" — random from OT + NT + Apocrypha
            result = lookup.random_verse_from_books(BIBLE_OT + BIBLE_NT + BIBLE_APOCRYPHA)
            await _send_result(ctx, result)
        return

    # Check for DRB suffix
    parts = ref.rsplit(None, 1)
    if len(parts) == 2 and parts[1].lower() in DRB_SUFFIXES:
        result = get_verse_drb(parts[0].strip())
        await _send_result(ctx, result)
        return

    # Try normal lookup first
    result = lookup.get_verse(ref)
    if result["found"]:
        await _send_result(ctx, result)
        return

    # If it failed to parse (no chapter:verse) try it as a book name for random verse
    if "Could not parse" in result.get("error", ""):
        result = lookup.random_verse_from_book(ref)

    await _send_result(ctx, result)


@bot.command(name="search", aliases=["find"])
async def search_prefix(ctx, *, query: str):
    results = lookup.search(query, limit=5)
    if not results:
        await ctx.send(f"No results found for **{query}**.")
        return
    embed = discord.Embed(
        title=f'Search results for "{query}"',
        color=discord.Color.gold()
    )
    for r in results:
        embed.add_field(
            name=r["reference"],
            value=r["text"][:200] + ("…" if len(r["text"]) > 200 else ""),
            inline=False
        )
    await ctx.send(embed=embed)


# ── !books — Hierarchical scripture browser ────────────────────────────────────

BOOKS_TREE = [
    ("📖 The Bible", [
        ("Old Testament", [
            "Genesis","Exodus","Leviticus","Numbers","Deuteronomy","Joshua",
            "Judges","Ruth","1 Samuel","2 Samuel","1 Kings","2 Kings",
            "1 Chronicles","2 Chronicles","Ezra","Nehemiah","Esther","Job",
            "Psalms","Proverbs","Ecclesiastes","Song of Solomon","Isaiah",
            "Jeremiah","Lamentations","Ezekiel","Daniel","Hosea","Joel",
            "Amos","Obadiah","Jonah","Micah","Nahum","Habakkuk","Zephaniah",
            "Haggai","Zechariah","Malachi",
        ]),
        ("New Testament", [
            "Matthew","Mark","Luke","John","Acts","Romans",
            "1 Corinthians","2 Corinthians","Galatians","Ephesians",
            "Philippians","Colossians","1 Thessalonians","2 Thessalonians",
            "1 Timothy","2 Timothy","Titus","Philemon","Hebrews","James",
            "1 Peter","2 Peter","1 John","2 John","3 John","Jude","Revelation",
        ]),
    ]),
    ("👼 Apocrypha / Pseudepigrapha", [
        ("Apocrypha (KJV)", [
            "1 Esdras","2 Esdras","Tobit","Judith","Additions to Esther",
            "Wisdom of Solomon","Sirach","Baruch","Epistle of Jeremiah",
            "Song of the Three Children","Susanna","Bel and the Dragon",
            "Prayer of Manasseh","1 Maccabees","2 Maccabees",
        ]),
        ("Pseudepigrapha", [
            "3 Maccabees","4 Maccabees","Psalms of Solomon",
            "Psalm 151","Psalm 152","Psalm 153","Psalm 154","Psalm 155",
            "Book of Enoch","Book of Jubilees",
        ]),
    ]),
    ("✡️ Halakha / Kabbalah", [
        ("Halakha", [
            ("Mishnah", [
                "Berakhot","Peah","Demai","Kilayim","Sheviit",
                "Terumot","Maasrot","Maaser Sheni","Challah","Orlah","Bikkurim",
                "Shabbat","Eruvin","Pesachim","Shekalim","Yoma","Sukkah",
                "Beitzah","Rosh Hashanah","Taanit","Megillah","Moed Katan","Chagigah",
                "Yevamot","Ketubot","Nedarim","Nazir","Sotah","Gittin","Kiddushin",
                "Bava Kamma","Bava Metzia","Bava Batra","Sanhedrin","Makkot",
                "Shevuot","Eduyot","Avodah Zarah","Avot","Horayot",
                "Zevachim","Menachot","Chullin","Bechorot","Arachin",
                "Temurah","Keritot","Meilah","Tamid","Middot","Kinnim",
                "Keilim","Ohalot","Negaim","Parah","Taharot","Mikvaot",
                "Niddah","Machshirin","Zavim","Tevul Yom","Yadayim","Oktzin",
            ]),
            ("Talmud Bavli", [
                "Berakhot","Shabbat","Eruvin","Pesachim","Shekalim","Yoma","Sukkah",
                "Beitzah","Rosh Hashanah","Taanit","Megillah","Moed Katan","Chagigah",
                "Yevamot","Ketubot","Nedarim","Nazir","Sotah","Gittin","Kiddushin",
                "Bava Kamma","Bava Metzia","Bava Batra","Sanhedrin","Makkot",
                "Shevuot","Avodah Zarah","Horayot",
                "Zevachim","Menachot","Chullin","Bechorot","Arachin",
                "Temurah","Keritot","Meilah","Tamid","Niddah",
            ]),
        ]),
        ("Kabbalah", [
            "Zohar",
        ]),
    ]),
    ("☪️ Islamic", [
        ("Quran", ["Quran"]),
        ("Hadith", [
            "Sahih al-Bukhari","Sahih Muslim","Sunan Abu Dawud",
            "Jami at-Tirmidhi","Sunan an-Nasa'i","Sunan Ibn Majah",
            "Muwatta Malik","Forty Hadith of Nawawi",
        ]),
    ]),
    ("🏛️ Classical", [
        ("Epic Poetry", [
            ("Homer", ["Iliad", "Odyssey"]),
            ("Virgil", ["Aeneid"]),
        ]),
        ("Theogonies & Hymns", [
            ("Hesiod", ["Theogony"]),
            ("Homeric", ["Homeric Hymns"]),
            ("Orphic", ["Orphic Hymns"]),
            ("Pythagorean", ["Golden Verses of Pythagoras"]),
        ]),
        ("Platonic & Neoplatonic", [
            ("Orphic", ["Orphic Hymns"]),
            ("Pythagorean", [
                "Golden Verses of Pythagoras",
                "Golden Sentences of Democrates",
                "Pythagorean Sentences of Demophilus",
                "Similitudes of Demophilus",
                "Pythagorean Sentences from Stobaeus",
                "Select Sentences of Sextus the Pythagorean",
                "Pythagorean Sentences from Iamblichus",
                "Symbols of Pythagoras",
            ]),
            ("Plato", [
                "Euthyphro", "Apology", "Crito", "Phaedo", "Cratylus",
                "Theaetetus", "Sophist", "Statesman", "Parmenides", "Philebus",
                "Symposium", "Phaedrus", "Alcibiades I", "Alcibiades II",
                "Hipparchus", "Rival Lovers", "Theages", "Charmides", "Laches",
                "Lysis", "Euthydemus", "Protagoras", "Gorgias", "Meno",
                "Greater Hippias", "Lesser Hippias", "Ion", "Menexenus",
                "Cleitophon", "Republic", "Timaeus", "Critias", "Minos",
                "Laws", "Epinomis", "Letters",
                "Axiochus", "On Justice", "On Virtue", "Demodocus",
                "Sisyphus", "Eryxias", "Definitions",
            ]),
            ("Philo of Alexandria", [
                "On the Creation",
                "Allegorical Interpretation I",
                "Allegorical Interpretation II",
                "Allegorical Interpretation III",
                "On the Cherubim",
                "On the Birth of Abel",
                "Worse Attacks the Better",
                "On the Posterity of Cain",
                "On the Giants",
                "On the Unchangeableness of God",
                "On Husbandry",
                "On Noah's Work as a Planter",
                "On Drunkenness",
                "On Sobriety",
                "On the Confusion of Tongues",
                "On the Migration of Abraham",
                "Who is the Heir of Divine Things",
                "On Mating",
                "On Flight and Finding",
                "On the Change of Names",
                "On Abraham",
                "On Joseph",
                "On the Life of Moses I",
                "On the Life of Moses II",
                "The Decalogue",
                "The Special Laws I",
                "The Special Laws II",
                "The Special Laws III",
                "The Special Laws IV",
                "On the Virtues",
                "On Rewards and Punishments",
                "Every Good Man is Free",
                "On the Contemplative Life",
                "On the Eternity of the World",
                "Flaccus",
                "On the Embassy to Gaius",
                "Questions on Genesis I",
                "Questions on Genesis II",
                "Questions on Genesis III",
            ]),
            ("Plotinus", ["Enneads"]),
            ("Porphyry", [
                "Life of Plotinus",
                "Life of Pythagoras",
                "On Abstinence",
                "On the Cave of the Nymphs",
                "Auxiliaries to the Intelligibles",
                "Letter to Marcella",
            ]),
            ("Iamblichus", [
                "On the Mysteries",
                "Life of Pythagoras",
            ]),
            ("Julian", [
                "Hymn to King Helios",
                "Hymn to the Mother of Gods",
                "Against the Galilaeans",
                "The Caesars",
            ]),
            ("Sallustius", ["On the Gods and the World"]),
            ("Proclus", [
                "Hymns of Proclus",
                "Theology of Plato",
                "Elements of Theology",
            ]),
            ("Hierocles", ["Commentary on the Golden Verses"]),
            ("Marinus", ["Life of Proclus"]),
            ("Dionysius the Areopagite", [
                "Divine Names",
                "Mystical Theology",
                "On the Heavenly Hierarchy",
                "On the Ecclesiastical Hierarchy",
            ]),
        ]),
        ("Aristotelian", [
            ("Ethics & Politics", [
                "Nicomachean Ethics",
                "Eudemian Ethics",
                "Politics",
                "Economics",
                "Athenian Constitution",
            ]),
            ("Logic (Organon)", [
                "Categories",
                "On Interpretation",
                "Prior Analytics",
                "Posterior Analytics",
                "Topics",
                "On Sophistical Refutations",
            ]),
            ("Natural Philosophy", [
                "Physics",
                "On the Heavens",
                "On Generation and Corruption",
                "Meteorology",
                "On the Soul",
                "On Memory and Reminiscence",
                "On Dreams",
                "On Sleep and Sleeplessness",
                "On Prophesying by Dreams",
                "On Sense and the Sensible",
                "On Longevity and Shortness of Life",
                "On Youth, Old Age, Life and Death",
            ]),
            ("Biology", [
                "History of Animals",
                "On the Parts of Animals",
                "On the Motion of Animals",
                "On the Gait of Animals",
                "On the Generation of Animals",
            ]),
            ("Rhetoric & Poetics", [
                "Rhetoric",
                "Poetics",
                "Metaphysics",
            ]),
        ]),
        ("Hermetic", [
            "Corpus Hermeticum",
            "Asclepius",
        ]),
        ("Oracular", [
            "Delphic Maxims",
            "Oracular Statements",
            "Chaldaean Oracles",
        ]),
    ]),
    ("📯 LDS", [
        ("Book of Mormon", [
            "1 Nephi","2 Nephi","Jacob","Enos","Jarom","Omni",
            "Words of Mormon","Mosiah","Alma","Helaman","3 Nephi","4 Nephi",
            "Mormon","Ether","Moroni",
        ]),
        ("Doctrine & Covenants", [
            "Doctrine and Covenants",
        ]),
        ("Pearl of Great Price", [
            "Moses","Abraham","Joseph Smith—Matthew","Joseph Smith—History",
            "Articles of Faith",
        ]),
    ]),
    ("🌍 Bahá'í", [
        "Kitab-i-Aqdas",
    ]),
    ("🔥 Zoroastrian", [
        "Gathas",
    ]),
    ("🧿 Gnostic", [
        "Ginza Rba",
        "Book of John",
    ]),
    ("🌲 Norse", [
        ("Poetic Edda", [
            "Voluspo", "Hovamol", "Vafthruthnismol", "Grimnismol", "Skirnismol",
            "Harbarthsljoth", "Hymiskvitha", "Lokasenna", "Thrymskvitha", "Alvissmol",
            "Baldrs Draumar", "Rigsthula", "Hyndluljoth", "Svipdagsmol",
            "Völundarkvitha", "Helgakvitha Hjorvarthssonar",
            "Helgakvitha Hundingsbana I", "Helgakvitha Hundingsbana II",
            "Fra Dautha Sinfjotla", "Gripisspo", "Reginsmol", "Fafnismol",
            "Sigrdrifumol", "Brot af Sigurtharkvithu", "Guthrunarkvitha I",
            "Sigurtharkvitha en Skamma", "Helreith Brynhildar", "Drap Niflunga",
            "Guthrunarkvitha II", "Guthrunarkvitha III", "Oddrunargratr",
            "Atlakvitha en Gronlenzka", "Atlamol en Gronlenzku",
            "Guthrunarhvot", "Hamthesmol",
        ]),
    ]),
    ("☸️ Dharmic", [
        ("Vedas", [
            "Rig Veda",
            "Yajur Veda",
            "Sama Veda",
            "Atharva Veda",
        ]),
    ]),
    ("⛪ Patristics & Church History", [
        ("Apostolic Fathers", [
            "1 Clement","2 Clement",
            "Ignatius to the Ephesians","Ignatius to the Magnesians",
            "Ignatius to the Trallians","Ignatius to the Romans",
            "Ignatius to the Philadelphians","Ignatius to the Smyrnaeans",
            "Ignatius to Polycarp",
            "Polycarp to the Philippians","Martyrdom of Polycarp",
            "Epistle of Barnabas","Didache","Shepherd of Hermas",
        ]),
        ("Dionysius the Areopagite", [
            "Divine Names",
            "Mystical Theology",
            "On the Heavenly Hierarchy",
            "On the Ecclesiastical Hierarchy",
            "Letters of Dionysius",
            "Liturgy of St. Dionysius",
        ]),
        ("Church History", [
            "Jewish Antiquities",
            "Jewish War",
            "Against Apion",
            "Life",
        ]),
    ]),
]


def _count_leaves(node) -> int:
    count = 0
    for item in node:
        if isinstance(item, tuple):
            count += _count_leaves(item[1])
        else:
            count += 1
    return count


def _books_embed(node, title: str) -> discord.Embed:
    lines = []
    for item in node:
        if isinstance(item, tuple):
            sub_name, sub_contents = item
            count = _count_leaves(sub_contents)
            lines.append(f"**{sub_name}** ({count})")
        else:
            n = lookup.chapter_count(item)
            lines.append(f"  {item} ({n} ch.)" if n else f"  {item}")
    embed = discord.Embed(
        title=f"📚 {title}",
        description="\n".join(lines) or "Nothing loaded yet.",
        color=discord.Color.dark_gold()
    )
    embed.set_footer(text="Click a category to expand it · !verse <book> for a random verse")
    return embed


def _find_node(tree, label: str):
    for item in tree:
        if isinstance(item, tuple):
            name, contents = item
            if name == label:
                return (name, contents)
            found = _find_node(contents, label)
            if found:
                return found
    return None


class BooksView(discord.ui.View):
    def __init__(self, stack: list):
        super().__init__(timeout=120)
        self.stack = stack
        self._rebuild()

    def _rebuild(self):
        self.clear_items()
        node = self.stack[-1][1]
        subcats = [item for item in node if isinstance(item, tuple)]

        # Distribute subcategory buttons across rows (max 5 per row, 4 rows for content)
        for i, (sub_name, sub_contents) in enumerate(subcats[:20]):
            # Strip emoji prefix for button label, keep it short
            label = sub_name
            for emoji in ("📖 ","👼 ","✡️ ","☪️ ","🏛️ ","📯 ","🌍 ","🔥 ","🧿 ","⛪ "):
                label = label.replace(emoji, "")
            label = label[:80]
            btn = discord.ui.Button(
                label=label,
                style=discord.ButtonStyle.primary,
                row=i // 5
            )
            btn.callback = self._make_drill(sub_name, sub_contents)
            self.add_item(btn)

        # Back button on last row
        if len(self.stack) > 1:
            back_btn = discord.ui.Button(
                label="◀ Back",
                style=discord.ButtonStyle.secondary,
                row=4
            )
            back_btn.callback = self._go_back
            self.add_item(back_btn)

    def _make_drill(self, name, contents):
        async def callback(interaction: discord.Interaction):
            self.stack.append((name, contents))
            self._rebuild()
            await interaction.response.edit_message(embed=_books_embed(contents, name), view=self)
        return callback

    async def _go_back(self, interaction: discord.Interaction):
        self.stack.pop()
        self._rebuild()
        label, node = self.stack[-1]
        await interaction.response.edit_message(embed=_books_embed(node, label), view=self)

    async def on_timeout(self):
        try:
            await self.message.edit(view=None)
        except Exception:
            pass


@bot.command(name="books")
async def list_books(ctx, *, section: str = ""):
    """Browse available scripture collections."""
    top_label = "Available Scripture"
    top_node  = BOOKS_TREE

    if section.strip():
        found = _find_node(BOOKS_TREE, section.strip())
        if found:
            label, node = found
            stack = [(top_label, top_node), (label, node)]
        else:
            await ctx.send(f"Section **{section}** not found.")
            return
    else:
        stack = [(top_label, top_node)]

    label, node = stack[-1]
    view = BooksView(stack)
    view.message = await ctx.send(embed=_books_embed(node, label), view=view)



# ── !votd — Verse of the Day (reference from verseoftheday.com, text from KJV) -

@bot.command(name="votd", aliases=["verseoftheday", "dayverse"])
async def cmd_votd(ctx):
    """Fetch today's verse reference and return it in KJV. Usage: !votd"""
    import urllib.request
    import html as html_mod

    url = "https://www.verseoftheday.com/"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            raw = r.read().decode("utf-8")
    except Exception as e:
        await ctx.send(f"⚠️ Could not fetch Verse of the Day: {e}")
        return

    # Strip tags to plain text
    text_only = html_mod.unescape(re.sub(r"<[^>]+>", " ", raw))
    text_only = re.sub(r"[ \t]+", " ", text_only).strip()

    # Grab the reference after the em-dash: —Isaiah 53:5-6
    ref_m = re.search(
        r"[—\-]{1,2}\s*([1-3]?\s*[A-Z][a-zA-Z]+\.?\s+\d+:\d+(?:\s*[-–]\s*\d+)?)",
        text_only
    )
    if not ref_m:
        await ctx.send(f"⚠️ Could not find today's verse reference. Visit: <{url}>")
        return

    reference = ref_m.group(1).strip()

    # Date line for the footer
    date_m = re.search(
        r"for\s+((?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)[^\[\n]+)",
        text_only
    )
    date_text = date_m.group(1).strip() if date_m else ""

    # Now look it up in our local KJV data
    result = lookup.get_verse(reference)

    if not result.get("found"):
        # Might be a verse range like "Isaiah 53:5-6" — try just the first verse
        first_ref = re.sub(r"\s*[-–]\s*\d+$", "", reference)
        result = lookup.get_verse(first_ref)

    if not result.get("found"):
        await ctx.send(
            f"⚠️ Today's verse is **{reference}** but it couldn't be found in the local KJV data.\n"
            f"Try: `!verse {reference}`"
        )
        return

    embed = discord.Embed(
        title=f"📖 {reference} (KJV)",
        description=result["text"],
        color=discord.Color.blue(),
        url=url
    )
    embed.set_footer(text=f"Verse of the Day — {date_text} | King James Version")
    await ctx.send(embed=embed)


# ── !catena — Patristic commentary from catenabible.com ──────────────────────

# Book name → catenabible.com URL abbreviation
_CATENA_BOOKS = {
    # OT
    "genesis": "gn", "gen": "gn",
    "exodus": "ex", "exod": "ex",
    "leviticus": "lv", "lev": "lv",
    "numbers": "nm", "num": "nm",
    "deuteronomy": "dt", "deut": "dt",
    "joshua": "jo", "josh": "jo",
    "judges": "jg", "judg": "jg",
    "ruth": "rt",
    "1 samuel": "1sm", "1sam": "1sm",
    "2 samuel": "2sm", "2sam": "2sm",
    "1 kings": "1kgs", "1kgs": "1kgs",
    "2 kings": "2kgs", "2kgs": "2kgs",
    "1 chronicles": "1chr", "1chr": "1chr",
    "2 chronicles": "2chr", "2chr": "2chr",
    "ezra": "ezr",
    "nehemiah": "ne", "neh": "ne",
    "tobit": "tb", "tob": "tb",
    "judith": "jdt",
    "esther": "est",
    "1 maccabees": "1mc", "1macc": "1mc",
    "2 maccabees": "2mc", "2macc": "2mc",
    "job": "jb",
    "psalms": "ps", "psalm": "ps",
    "proverbs": "prv", "prov": "prv",
    "ecclesiastes": "eccl", "qoheleth": "eccl",
    "song of songs": "sg", "song of solomon": "sg", "song": "sg",
    "wisdom": "wis", "wisdom of solomon": "wis",
    "sirach": "si", "ecclesiasticus": "si",
    "isaiah": "is", "isa": "is",
    "jeremiah": "jer",
    "lamentations": "lam",
    "baruch": "bar",
    "ezekiel": "ez", "ezek": "ez",
    "daniel": "dn", "dan": "dn",
    "hosea": "hos",
    "joel": "jl",
    "amos": "am",
    "obadiah": "ob",
    "jonah": "jon",
    "micah": "mi",
    "nahum": "na",
    "habakkuk": "hb", "hab": "hb",
    "zephaniah": "zep",
    "haggai": "hg",
    "zechariah": "zec",
    "malachi": "mal",
    # NT
    "matthew": "mt", "matt": "mt",
    "mark": "mk",
    "luke": "lk",
    "john": "jn",
    "acts": "ac", "acts of the apostles": "ac",
    "romans": "rom",
    "1 corinthians": "1cor", "1cor": "1cor",
    "2 corinthians": "2cor", "2cor": "2cor",
    "galatians": "gal",
    "ephesians": "eph",
    "philippians": "phil",
    "colossians": "col",
    "1 thessalonians": "1thes", "1thess": "1thes",
    "2 thessalonians": "2thes", "2thess": "2thes",
    "1 timothy": "1tm", "1tim": "1tm",
    "2 timothy": "2tm", "2tim": "2tm",
    "titus": "ti",
    "philemon": "phm",
    "hebrews": "heb",
    "james": "jas",
    "1 peter": "1pt", "1pet": "1pt",
    "2 peter": "2pt", "2pet": "2pt",
    "1 john": "1jn",
    "2 john": "2jn",
    "3 john": "3jn",
    "jude": "jude",
    "revelation": "rv", "rev": "rv", "apocalypse": "rv",
}

def _catena_book_abbr(book_raw: str) -> str | None:
    """Return the catenabible.com URL abbreviation for a book name."""
    key = book_raw.strip().lower()
    if key in _CATENA_BOOKS:
        return _CATENA_BOOKS[key]
    # Try stripping leading digit+space for numbered books
    for k, v in _CATENA_BOOKS.items():
        if key == k:
            return v
    return None

@bot.command(name="catena")
async def cmd_catena(ctx, *, reference: str = ""):
    """Fetch patristic commentary from catenabible.com. Usage: !catena John 3:16"""
    import urllib.request
    import html as html_mod

    if not reference:
        await ctx.send("Usage: `!catena John 3:16`")
        return

    # Parse "Book Chapter:Verse"
    m = re.match(
        r"^((?:\d\s*)?[A-Za-z][a-zA-Z\s]+?)\s+(\d+):(\d+)$",
        reference.strip()
    )
    if not m:
        await ctx.send(f"⚠️ Couldn't parse `{reference}`. Try: `!catena John 3:16`")
        return

    book_raw, chapter, verse = m.group(1).strip(), m.group(2), m.group(3)
    abbr = _catena_book_abbr(book_raw)
    if abbr is None:
        await ctx.send(f"⚠️ Book `{book_raw}` not found on catenabible.com.")
        return

    url = f"https://catenabible.com/{abbr}/{chapter}/{verse}"

    async with ctx.typing():
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                    "Accept": "text/html,application/xhtml+xml",
                    "Accept-Language": "en-US,en;q=0.9",
                }
            )
            with urllib.request.urlopen(req, timeout=15) as r:
                raw = r.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            await ctx.send(f"⚠️ catenabible.com returned HTTP {e.code} for `{reference}`.\nVisit: <{url}>")
            return
        except Exception as e:
            await ctx.send(f"⚠️ Could not reach catenabible.com: {e}")
            return

    # ── Parse commentary sections ─────────────────────────────────────────────
    text = html_mod.unescape(re.sub(r"<[^>]+>", " ", raw))
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()

    for cutoff in ["All Commentaries on", "Knowing this first", "Go To "]:
        idx = text.find(cutoff)
        if idx != -1:
            text = text[:idx].strip()

    # Start at first "Name AD YYYY" — skips the nav dump
    ad_match = re.search(r"\b[A-Z][a-zA-Z ]+AD \d{3,4}", text)
    if ad_match:
        text = text[ad_match.start():]

    text = re.sub(r"chevron-(?:left|right)", "", text)
    text = re.sub(r"Verse \d+\s+Read Chapter \d+\s+Verse \d+", "", text)
    text = re.sub(r"\d+ min\s+\d+ / \d+\s+Go to Commentary", "", text)
    text = re.sub(r"Read Chapter \d+", "", text)

    entries = re.split(r"\n*([A-Z][a-zA-Z ]+AD \d{3,4})\n*", text)
    sections = []
    i = 1
    while i < len(entries) - 1:
        name = entries[i].strip()
        body = re.sub(r"\s*\d+ min\s*\d* ?/? ?\d*\s*Go to Commentary\s*", "", entries[i + 1]).strip()
        if body and len(body) > 20:
            sections.append((name, body))
        i += 2

    if not sections:
        await ctx.send(f"⚠️ No commentary found for **{book_raw} {chapter}:{verse}**.\nVisit: <{url}>")
        return

    # ── Get KJV verse text ────────────────────────────────────────────────────
    ref_label = f"{book_raw.title()} {chapter}:{verse}"
    kjv_result = lookup.get_verse(f"{book_raw} {chapter}:{verse}")
    kjv_text = f"*{kjv_result['text']}*\n\n" if kjv_result.get("found") else ""

    # ── Build paginated view ──────────────────────────────────────────────────
    def make_embed(idx: int) -> discord.Embed:
        name, body = sections[idx]
        # Truncate body at sentence boundary if very long
        if len(body) > 3200 - len(kjv_text):
            limit = 3200 - len(kjv_text)
            trunc = body[:limit]
            last_period = trunc.rfind(". ")
            body = (trunc[:last_period + 1] if last_period > 200 else trunc) + " …"

        embed = discord.Embed(
            title=f"📜 {ref_label} — {name}",
            description=kjv_text + body,
            color=discord.Color.dark_gold(),
            url=url
        )
        embed.set_footer(text=f"Commentary {idx + 1} of {len(sections)} — catenabible.com")
        return embed

    class CatenaView(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=120)
            self.idx = 0

        @discord.ui.button(emoji="◀", style=discord.ButtonStyle.secondary)
        async def prev(self, interaction: discord.Interaction, button: discord.ui.Button):
            self.idx = (self.idx - 1) % len(sections)
            await interaction.response.edit_message(embed=make_embed(self.idx), view=self)

        @discord.ui.button(emoji="▶", style=discord.ButtonStyle.secondary)
        async def next(self, interaction: discord.Interaction, button: discord.ui.Button):
            self.idx = (self.idx + 1) % len(sections)
            await interaction.response.edit_message(embed=make_embed(self.idx), view=self)

        async def on_timeout(self):
            # Remove buttons when the view expires
            try:
                await self.message.edit(view=None)
            except Exception:
                pass

    view = CatenaView()
    msg = await ctx.send(embed=make_embed(0), view=view)
    view.message = msg


# ── !gematria — Gematria lookup via gematrix.org ─────────────────────────────

_gematria_cooldowns: dict[int, list] = {}  # user_id → [timestamps]

@bot.command(name="gematria", aliases=["gem", "gematrix"])
async def cmd_gematria(ctx, *, query: str = ""):
    """Look up gematria values. Usage: !gematria love  or  !gematria 666"""
    import urllib.request, urllib.parse
    import html as html_mod

    if not query:
        await ctx.send("Usage: `!gematria <word or phrase or number>`")
        return

    encoded = urllib.parse.quote_plus(query.strip())
    url = f"https://www.gematrix.org/?word={encoded}"

    async with ctx.typing():
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Accept": "text/html",
                }
            )
            with urllib.request.urlopen(req, timeout=15) as r:
                raw = r.read().decode("utf-8")
        except Exception as e:
            await ctx.send(f"⚠️ Could not reach gematrix.org: {e}")
            return

    # ── Parse the results table ───────────────────────────────────────────────
    # Each row: word | jewish | english | simple | searches
    row_re = re.compile(
        r'<tr[^>]*>.*?'
        r'<td[^>]*><a[^>]*>([^<]+)</a></td>'   # word
        r'\s*<td[^>]*><a[^>]*>(\d+)</a></td>'  # jewish
        r'\s*<td[^>]*><a[^>]*>(\d+)</a></td>'  # english
        r'\s*<td[^>]*><a[^>]*>(\d+)</a></td>'  # simple
        r'\s*<td[^>]*>(\d+)</td>',              # searches (ignored)
        re.DOTALL
    )
    rows = row_re.findall(raw)

    # Fallback: find computed values for the phrase itself
    computed = {}
    for cipher in ["Jewish", "English", "Simple"]:
        vm = re.search(rf'in {cipher} Gematria equals (\d+)', raw, re.IGNORECASE)
        if vm:
            computed[cipher.lower()] = vm.group(1)

    if not rows and not computed:
        await ctx.send(f"⚠️ No gematria results found for **{query}**.\nTry: <{url}>")
        return

    # ── Format as compact list ────────────────────────────────────────────────
    label = query.strip()

    def fmt_row(word, jewish, english, simple):
        values = f"{jewish:<8} {english:<8} {simple}"
        if len(word) <= 32:
            return f"{word:<32} {values}"
        else:
            return f"{word}\n{'':32} {values}"

    header  = f"{'Word':<32} {'Jew.':<8} {'Eng.':<8} {'Smp.'}"
    divider = "─" * 56
    lines   = [header, divider]
    lines   = [header, divider]

    top_jewish = top_english = top_simple = None

    for i, (word, jewish, english, simple, _) in enumerate(rows[:10]):
        word = html_mod.unescape(word).strip()
        lines.append(fmt_row(word, jewish, english, simple))
        if i == 0:
            top_jewish, top_english, top_simple = jewish, english, simple

    if not rows and computed:
        lines.append(fmt_row(
            label,
            computed.get('jewish', '?'),
            computed.get('english', '?'),
            computed.get('simple', '?')
        ))
        top_jewish  = computed.get("jewish")
        top_english = computed.get("english")
        top_simple  = computed.get("simple")

    table = "```\n" + "\n".join(lines) + "\n```"
    count = len(rows)

    embed = discord.Embed(
        title=f"🔢 Gematria — {label}",
        description=table,
        color=discord.Color.purple(),
        url=url
    )
    embed.set_footer(text=f"{min(count, 10)} of {count} results — gematrix.org")

    # ── Buttons: click to search by that value ────────────────────────────────
    class GematriaButton(discord.ui.Button):
        def __init__(self, label, value, style):
            super().__init__(label=label, style=style)
            self.value = value

        async def callback(self, interaction: discord.Interaction):
            import time
            now = time.monotonic()
            user_id = interaction.user.id

            # Rate limit: max 3 clicks per 10 seconds per user
            history = _gematria_cooldowns.setdefault(user_id, [])
            # Prune entries older than 10 seconds
            _gematria_cooldowns[user_id] = [t for t in history if now - t < 10]
            if len(_gematria_cooldowns[user_id]) >= 3:
                await interaction.response.send_message(
                    "🛑 Slow down! You can only search 3 times per 10 seconds.",
                    ephemeral=True
                )
                return

            _gematria_cooldowns[user_id].append(now)
            await interaction.response.defer(ephemeral=True)

            encoded = urllib.parse.quote_plus(self.value)
            url = f"https://www.gematrix.org/?word={encoded}"
            try:
                req = urllib.request.Request(
                    url,
                    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
                )
                with urllib.request.urlopen(req, timeout=15) as r:
                    raw2 = r.read().decode("utf-8")
            except Exception as e:
                await interaction.followup.send(f"⚠️ Could not reach gematrix.org: {e}", ephemeral=True)
                return

            rows2 = row_re.findall(raw2)
            computed2 = {}
            for cipher in ["Jewish", "English", "Simple"]:
                vm = re.search(rf'in {cipher} Gematria equals (\d+)', raw2, re.IGNORECASE)
                if vm:
                    computed2[cipher.lower()] = vm.group(1)

            if not rows2 and not computed2:
                await interaction.followup.send(f"⚠️ No results for **{self.value}**.", ephemeral=True)
                return

            lines2 = [header, divider]
            for i, (word, jewish, english, simple, _) in enumerate(rows2[:10]):
                word = html_mod.unescape(word).strip()
                lines2.append(fmt_row(word, jewish, english, simple))

            if not rows2 and computed2:
                lines2.append(fmt_row(
                    self.value,
                    computed2.get('jewish', '?'),
                    computed2.get('english', '?'),
                    computed2.get('simple', '?')
                ))

            count2 = len(rows2)
            table2 = "```\n" + "\n".join(lines2) + "\n```"
            embed2 = discord.Embed(
                title=f"🔢 Gematria — {self.value}",
                description=table2,
                color=discord.Color.purple(),
                url=url
            )
            embed2.set_footer(text=f"{min(count2, 10)} of {count2} results — gematrix.org")
            await interaction.followup.send(embed=embed2, ephemeral=True)

    class GematriaView(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=120)
            seen = set()
            styles = [
                discord.ButtonStyle.primary,
                discord.ButtonStyle.secondary,
                discord.ButtonStyle.success,
            ]
            pairs = [
                (f"Jewish {top_jewish}", top_jewish),
                (f"English {top_english}", top_english),
                (f"Simple {top_simple}", top_simple),
            ]
            for (lbl, val), style in zip(pairs, styles):
                if val and val not in seen:
                    self.add_item(GematriaButton(lbl, val, style))
                    seen.add(val)

    await ctx.send(embed=embed, view=GematriaView())


# ── !virgil — Sortes Vergilianae ──────────────────────────────────────────────

_AENEID_DATA = None

def _load_aeneid():
    global _AENEID_DATA
    if _AENEID_DATA is None:
        import json, pathlib
        path = pathlib.Path(__file__).parent / "data" / "classical" / "aeneid.json"
        if path.exists():
            _AENEID_DATA = json.loads(path.read_text(encoding="utf-8"))["books"]["Aeneid"]
    return _AENEID_DATA

@bot.command(name="virgil", aliases=["sortesvir", "aeneid"])
async def cmd_virgil(ctx, *, question: str = ""):
    """Consult the Sortes Vergilianae. Usage: !virgil [optional question]"""
    aeneid = _load_aeneid()
    if aeneid is None:
        await ctx.send("⚠️ Aeneid data not found. Run `build_data.py` step 20.")
        return

    # Pick a random book then a random line within it
    book_num = str(random.randint(1, 12))
    lines = aeneid.get(book_num, {})
    if not lines:
        await ctx.send("⚠️ No lines found for that book.")
        return

    line_num = random.randint(1, len(lines))
    verse_text = lines.get(str(line_num), "")

    # Visual: 📖 {book} 🕯️ {line} 👈
    display = f"📖 {book_num}  🕯️ {line_num}  👈"

    embed = discord.Embed(
        title="Sortes Vergilianae",
        description=f"{display}\n\n*{verse_text}*",
        color=discord.Color.dark_gold()
    )
    embed.set_footer(text="The Aeneid — Virgil (trans. John Dryden, 1697)")
    await ctx.send(embed=embed)


_HOMER_DATA = None

def _load_homer():
    global _HOMER_DATA
    if _HOMER_DATA is None:
        import json, pathlib
        path = pathlib.Path(__file__).parent / "data" / "classical" / "homeromanteion.json"
        if path.exists():
            _HOMER_DATA = json.loads(path.read_text(encoding="utf-8"))["oracle"]
    return _HOMER_DATA

@bot.command(name="homer", aliases=["homeromanteion", "sortes"])
async def cmd_homer(ctx, *, question: str = ""):
    """Roll three dice and receive a Homeric oracle. Usage: !homer"""
    d1, d2, d3 = random.randint(1,6), random.randint(1,6), random.randint(1,6)
    roll_str = f"{d1}-{d2}-{d3}"
    key = f"{d1}{d2}{d3}"

    oracle = _load_homer()
    if oracle is None:
        await ctx.send("⚠️ Homeromanteion data not found.")
        return

    text = oracle.get(key)
    dice_display = f"🎲 {d1}  🎲 {d2}  🎲 {d3}"

    if text is None:
        embed = discord.Embed(
            title=f"The Oracle is Silent  ({roll_str})",
            description=f"{dice_display}\n\n*The papyrus is blank for this combination. The gods withhold their answer.*",
            color=discord.Color.dark_gray()
        )
    else:
        embed = discord.Embed(
            title=f"Homeromanteion  ({roll_str})",
            description=f"{dice_display}\n\n*{text}*",
            color=discord.Color.blurple()
        )
    embed.set_footer(text="Sortes Homericae — PMG VII, Oxford Classical Text translations")
    await ctx.send(embed=embed)


@bot.command(name="delphi")
async def cmd_delphi(ctx):
    """Return a random Delphic maxim. Usage: !delphi"""
    maxims = lookup._data.get("classical", {}).get("Delphic Maxims", {})
    if not maxims:
        await ctx.send("Delphic Maxims data not found. Have you run `build_data.py`?")
        return
    num, chap = random.choice(list(maxims.items()))
    text = chap.get("1", "")
    embed = discord.Embed(
        title=f"Delphic Maxim {num}",
        description=text,
        color=discord.Color.gold()
    )
    embed.set_footer(text="Delphic Maxims — trans. Melissa Gold (Hellenion)")
    await ctx.send(embed=embed)


# ── !oracle — random verse from any oracular corpus ───────────────────────────

@bot.command(name="oracle")
async def cmd_oracle(ctx, *, question: str = ""):
    """Return a random verse from any oracular corpus. Usage: !oracle"""
    classical = lookup._data.get("classical", {})
    oracular_books = {
        "Delphic Maxims":      ("Delphic Maxims — trans. Melissa Gold (Hellenion)", "Delphi 1"),
        "Oracular Statements": ("Oracular Statements from Delphi", "Delphi 2"),
        "Chaldaean Oracles":   ("Chaldaean Oracles — ed. Westcott", "Chaldaean Oracles"),
        "Golden Verses":       ("Golden Verses of Pythagoras", "GVP"),
    }

    pool = []
    for book, (source, ref_prefix) in oracular_books.items():
        for num, chap in classical.get(book, {}).items():
            text = chap.get("1", "")
            if text:
                pool.append((book, num, text, source, ref_prefix))

    if not pool:
        await ctx.send("No oracular data found. Have you run `build_data.py`?")
        return

    book, num, text, source, ref_prefix = random.choice(pool)

    if len(text) > 1800:
        text = text[:1797] + "…"
    embed = discord.Embed(
        title=f"{book} — {num}",
        description=text,
        color=discord.Color.dark_purple()
    )
    embed.set_footer(text=source)
    await ctx.send(embed=embed)


# ── Auto-detection ─────────────────────────────────────────────────────────────

@bot.event
async def on_message(message: discord.Message):
    # Never respond to ourselves or other bots
    if message.author.bot:
        return

    # Still process !commands normally
    await bot.process_commands(message)

    # Don't double-trigger on explicit !verse commands
    if message.content.startswith("!"):
        return

    # Scan the message for scripture references
    matches = _AUTO_RE.findall(message.content)
    if not matches:
        return

    # De-duplicate while preserving order
    seen = set()
    unique = []
    for m in matches:
        book, chap, verse, end_verse = m
        ref = f"{book.strip()} {chap}:{verse}"
        if end_verse:
            ref += f"-{end_verse}"
        if ref.lower() not in seen:
            seen.add(ref.lower())
            unique.append(ref)

    # Only respond if at least one reference actually resolves to a real verse,
    # so we don't spam on false positives like "in 1 hour" or "at 3:00"
    embeds = []
    content = message.content
    for ref in unique[:3]:  # cap at 3 per message to avoid spam
        # Check if a DRB suffix follows this reference in the message
        escaped = re.escape(ref)
        drb_m = re.search(escaped + r"\s+(\S+)", content, re.IGNORECASE)
        if drb_m and drb_m.group(1).lower() in DRB_SUFFIXES:
            result = get_verse_drb(ref)
        else:
            result = lookup.get_verse(ref)
        if result["found"]:
            embeds.append(_build_embed(result))

    for embed in embeds:
        await message.channel.send(embed=embed)

# ── Helpers ────────────────────────────────────────────────────────────────────

def _build_embed(result: dict) -> discord.Embed:
    """Build a single embed — used by auto-detection in on_message."""
    if result["found"]:
        embed = discord.Embed(
            title=result["reference"],
            description=result["text"][:3900],
            color=discord.Color.dark_gold()
        )
        embed.set_footer(text=result["source"])
    else:
        embed = discord.Embed(
            title="Not found",
            description=result["error"],
            color=discord.Color.red()
        )
        if result.get("suggestions"):
            embed.add_field(
                name="Did you mean?",
                value="\n".join(result["suggestions"]),
                inline=False
            )
    return embed


def _chunk(text: str, size: int) -> list[str]:
    return [text[i:i+size] for i in range(0, len(text), size)]


async def _send_result(ctx_or_interaction, result: dict):
    """Send a verse or whole-chapter result, splitting across multiple embeds if needed."""
    if not result["found"]:
        embed = _build_embed(result)
        if hasattr(ctx_or_interaction, "response"):
            await ctx_or_interaction.response.send_message(embed=embed)
        else:
            await ctx_or_interaction.send(embed=embed)
        return

    # ── Paginated whole-chapter result ────────────────────────────────────────
    pages = result.get("pages")
    if pages and len(pages) > 1:
        ref    = result["reference"]
        source = result["source"]
        total  = len(pages)

        def make_page_embed(idx):
            text = pages[idx]
            if len(text) > 3900:
                text = text[:3897] + "…"
            embed = discord.Embed(
                title=f"{ref} ({idx + 1}/{total})",
                description=text,
                color=discord.Color.dark_gold()
            )
            embed.set_footer(text=source)
            return embed

        class ChapterView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=120)
                self.idx = 0

            @discord.ui.button(emoji="◀", style=discord.ButtonStyle.secondary)
            async def prev(self, interaction: discord.Interaction, button: discord.ui.Button):
                self.idx = (self.idx - 1) % total
                await interaction.response.edit_message(embed=make_page_embed(self.idx), view=self)

            @discord.ui.button(emoji="▶", style=discord.ButtonStyle.secondary)
            async def next(self, interaction: discord.Interaction, button: discord.ui.Button):
                self.idx = (self.idx + 1) % total
                await interaction.response.edit_message(embed=make_page_embed(self.idx), view=self)

            async def on_timeout(self):
                try:
                    await self.message.edit(view=None)
                except Exception:
                    pass

        view = ChapterView()
        if hasattr(ctx_or_interaction, "response"):
            await ctx_or_interaction.response.send_message(embed=make_page_embed(0), view=view)
            view.message = await ctx_or_interaction.original_response()
        else:
            view.message = await ctx_or_interaction.send(embed=make_page_embed(0), view=view)
        return

    MAX = 3900
    text   = result["text"]
    title  = result["reference"]
    source = result["source"]

    if len(text) <= MAX:
        embed = discord.Embed(title=title, description=text, color=discord.Color.dark_gold())
        embed.set_footer(text=source)
        if hasattr(ctx_or_interaction, "response"):
            await ctx_or_interaction.response.send_message(embed=embed)
        else:
            await ctx_or_interaction.send(embed=embed)
        return

    # Split long text into chunks at sentence or line boundaries
    chunks = []
    current = ""
    # Split on newlines first; if text is one long blob, split on sentences
    lines = text.split("\n")
    if len(lines) == 1 and len(text) > MAX:
        # No newlines — split on sentence boundaries
        sentences = re.split(r'(?<=[.!?])\s+', text)
        lines = sentences

    for line in lines:
        if len(current) + len(line) + 1 > MAX and current:
            chunks.append(current.strip())
            current = line
        else:
            current = (current + "\n" + line) if current else line
    if current:
        chunks.append(current.strip())

    for i, chunk in enumerate(chunks):
        part_title = title if len(chunks) == 1 else f"{title} ({i+1}/{len(chunks)})"
        embed = discord.Embed(title=part_title, description=chunk, color=discord.Color.dark_gold())
        if i == len(chunks) - 1:
            embed.set_footer(text=source)
        if i == 0 and hasattr(ctx_or_interaction, "response"):
            await ctx_or_interaction.response.send_message(embed=embed)
        else:
            channel = ctx_or_interaction.channel if hasattr(ctx_or_interaction, "response") else ctx_or_interaction
            await channel.send(embed=embed)


# ── Startup ────────────────────────────────────────────────────────────────────

# ── !ccc / !canon — Catechism and Canon Law ───────────────────────────────────

_CCC_DATA   = None
_CANON_DATA = None

def _load_ccc():
    global _CCC_DATA
    if _CCC_DATA is None:
        import json, pathlib
        path = pathlib.Path(__file__).parent / "data" / "catechism.json"
        if path.exists():
            entries = json.loads(path.read_text(encoding="utf-8"))
            _CCC_DATA = {e["id"]: e["text"].strip() for e in entries}
    return _CCC_DATA

def _load_canon():
    global _CANON_DATA
    if _CANON_DATA is None:
        import json, pathlib
        path = pathlib.Path(__file__).parent / "data" / "canon.json"
        if path.exists():
            entries = json.loads(path.read_text(encoding="utf-8"))
            _CANON_DATA = {}
            for e in entries:
                if "text" in e:
                    _CANON_DATA[e["id"]] = e["text"].strip()
                elif "sections" in e:
                    # Join numbered sub-sections
                    parts = []
                    for s in e["sections"]:
                        parts.append(f"§{s['id']}. {s['text'].strip()}")
                    _CANON_DATA[e["id"]] = "\n\n".join(parts)
    return _CANON_DATA

@bot.command(name="ccc")
async def cmd_ccc(ctx, *, args: str = ""):
    """Look up a paragraph of the Catechism of the Catholic Church. Usage: !ccc 1"""
    try:
        number = int(args.strip())
    except ValueError:
        await ctx.send("Usage: `!ccc <paragraph number>` (1–2865)")
        return
    if number <= 0:
        await ctx.send("Usage: `!ccc <paragraph number>` (1–2865)")
        return
    data = _load_ccc()
    if data is None:
        await ctx.send("⚠️ catechism.json not found in data folder.")
        return
    text = data.get(number)
    if text is None:
        await ctx.send(f"⚠️ Paragraph {number} not found. Valid range: 1–{max(data.keys())}.")
        return
    text = re.sub(r'\*+', '', text)
    if len(text) > 4000:
        text = text[:3997] + "…"
    embed = discord.Embed(
        title=f"CCC {number}",
        description=text,
        color=discord.Color.gold()
    )
    embed.set_footer(text="Catechism of the Catholic Church")
    await ctx.send(embed=embed)


@bot.command(name="canon")
async def cmd_canon(ctx, *, args: str = ""):
    """Look up a canon of the Code of Canon Law. Usage: !canon 1"""
    try:
        number = int(args.strip())
    except ValueError:
        await ctx.send("Usage: `!canon <canon number>` (1–1751)")
        return
    if number <= 0:
        await ctx.send("Usage: `!canon <canon number>` (1–1751)")
        return
    data = _load_canon()
    if data is None:
        await ctx.send("⚠️ canon.json not found in data folder.")
        return
    text = data.get(number)
    if text is None:
        await ctx.send(f"⚠️ Canon {number} not found. Valid range: 1–{max(data.keys())}.")
        return
    text = re.sub(r'\*+', '', text)
    if len(text) > 4000:
        text = text[:3997] + "…"
    embed = discord.Embed(
        title=f"Canon {number}",
        description=text,
        color=discord.Color.dark_red()
    )
    embed.set_footer(text="Code of Canon Law (1983)")
    await ctx.send(embed=embed)



    await bot.tree.sync()
    print(f"Logged in as {bot.user} ({bot.user.id})")
    print(f"Corpora loaded: {', '.join(lookup.corpora_names())}")

    # Set avatar from local file if present.
    # Place your image as "avatar.png" (or .jpg) in the same folder as bot.py.
    # Discord rate-limits avatar changes to roughly 2 per hour, so this only
    # actually sends the request if the file has changed since last run.
    import pathlib, hashlib
    for ext in ("png", "jpg", "jpeg", "gif", "webp"):
        avatar_path = pathlib.Path(__file__).parent / f"avatar.{ext}"
        if avatar_path.exists():
            avatar_bytes = avatar_path.read_bytes()
            avatar_hash = hashlib.md5(avatar_bytes).hexdigest()
            hash_cache = pathlib.Path(__file__).parent / ".avatar_hash"
            last_hash = hash_cache.read_text().strip() if hash_cache.exists() else ""
            if avatar_hash != last_hash:
                try:
                    await bot.user.edit(avatar=avatar_bytes)
                    hash_cache.write_text(avatar_hash)
                    print(f"Avatar updated from {avatar_path.name}")
                except Exception as e:
                    print(f"Could not update avatar: {e}")
            else:
                print("Avatar unchanged, skipping upload")
            break


if __name__ == "__main__":
    token = os.environ.get("DISCORD_TOKEN")
    if not token:
        raise RuntimeError("Set the DISCORD_TOKEN environment variable.")
    bot.run(token)
