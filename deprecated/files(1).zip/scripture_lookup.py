"""
scripture_lookup.py
-------------------
Handles all verse retrieval logic.

Data directory layout expected under  ./data/ :

  data/
    kjv/
      kjv_canon.json               # KJV Old + New Testament (66 books)
      kjv_apocrypha.json           # KJV Apocrypha (15 books)
    lds/
      book_of_mormon.json
      doctrine_and_covenants.json    # D&C uses sections, not chapters (treated the same)
      pearl_of_great_price.json      # Moses, Abraham, JS-Matthew, JS-History, Articles of Faith
    brenton/
      brenton_septuagint.json        # All LXX books including Psalms of Solomon, Prayer of Manasseh, etc.
    charles/
      book_of_enoch.json
      book_of_jubilees.json
    apostolic_fathers/               # J.B. Lightfoot translations
      1_clement.json
      2_clement.json
      ignatius_ephesians.json
      ignatius_magnesians.json
      ignatius_trallians.json
      ignatius_romans.json
      ignatius_philadelphians.json
      ignatius_smyrnaeans.json
      ignatius_polycarp.json
      polycarp_philippians.json
      martyrdom_of_polycarp.json
      epistle_of_barnabas.json
      didache.json
      shepherd_of_hermas.json        # Shepherd of Hermas (continuous chapter numbering)

Each JSON file must follow the schema:
  {
    "source": "King James Bible with Apocrypha",
    "books": {
      "BookName": {
        "1": {          // chapter (string key)
          "1": "text", // verse (string key)
          "2": "text"
        }
      }
    }
  }

For Doctrine & Covenants, treat each "section" as a "chapter".
For Articles of Faith (1 chapter, 13 articles), chapter = "1", verse = article number.
For Shepherd of Hermas, each part (Visions/Mandates/Similitudes) is its own book;
  chapter = the part's own chapter number, verse = sentence/paragraph number.
"""

from __future__ import annotations
import json
import os
import re
import unicodedata
from difflib import get_close_matches
from pathlib import Path
from typing import Optional

from sefaria_lookup import (
    resolve_tractate,
    parse_mishnah_ref,
    fetch_mishnah,
    fetch_mishnah_chapter,
    MISHNAH_TRACTATES,
    # Talmud Bavli
    get_talmud,
    parse_talmud_ref,
    resolve_talmud_tractate,
    TALMUD_TRACTATES,
    # Zohar
    get_zohar,
    parse_zohar_ref,
)
from hadith_lookup import (
    get_hadith,
    parse_hadith_ref,
    resolve_collection,
    HADITH_COLLECTIONS,
    COLLECTION_DISPLAY,
)

DATA_DIR = Path(__file__).parent / "data"

# ── Book alias table ───────────────────────────────────────────────────────────
# Maps every reasonable abbreviation → canonical name used in JSON files.
# Add more as needed.

ALIASES: dict[str, str] = {
    # ── Old Testament ──────────────────────────────────────────────────────
    "gen": "Genesis", "ge": "Genesis", "gn": "Genesis",
    "ex": "Exodus", "exod": "Exodus",
    "lev": "Leviticus", "lv": "Leviticus",
    "num": "Numbers", "nu": "Numbers", "nm": "Numbers",
    "deut": "Deuteronomy", "dt": "Deuteronomy", "deu": "Deuteronomy",
    "josh": "Joshua", "jos": "Joshua",
    "judg": "Judges", "jdg": "Judges",
    "ruth": "Ruth", "rth": "Ruth",
    "1sam": "1 Samuel", "1 sam": "1 Samuel", "1sa": "1 Samuel", "i sam": "1 Samuel",
    "2sam": "2 Samuel", "2 sam": "2 Samuel", "2sa": "2 Samuel",
    "1kgs": "1 Kings", "1 kgs": "1 Kings", "1ki": "1 Kings",
    "2kgs": "2 Kings", "2 kgs": "2 Kings", "2ki": "2 Kings",
    "1chr": "1 Chronicles", "1 chr": "1 Chronicles", "1ch": "1 Chronicles",
    "2chr": "2 Chronicles", "2 chr": "2 Chronicles", "2ch": "2 Chronicles",
    "ezra": "Ezra",
    "neh": "Nehemiah",
    "esth": "Esther",
    "job": "Job",
    "ps": "Psalms", "psa": "Psalms", "psalm": "Psalms",
    "prov": "Proverbs", "pro": "Proverbs", "prv": "Proverbs",
    "eccl": "Ecclesiastes", "ecc": "Ecclesiastes", "qoh": "Ecclesiastes",
    "song": "Song of Solomon", "sos": "Song of Solomon", "ss": "Song of Solomon",
    "isa": "Isaiah",
    "jer": "Jeremiah",
    "lam": "Lamentations",
    "ezek": "Ezekiel", "eze": "Ezekiel",
    "dan": "Daniel",
    "hos": "Hosea",
    "joel": "Joel",
    "amos": "Amos",
    "obad": "Obadiah",
    "jonah": "Jonah", "jon": "Jonah",
    "mic": "Micah",
    "nah": "Nahum",
    "hab": "Habakkuk",
    "zeph": "Zephaniah", "zep": "Zephaniah",
    "hag": "Haggai",
    "zech": "Zechariah", "zec": "Zechariah",
    "mal": "Malachi",
    # ── New Testament ──────────────────────────────────────────────────────
    "matt": "Matthew", "mt": "Matthew",
    "mark": "Mark", "mrk": "Mark",
    "luke": "Luke", "lk": "Luke",
    "john": "John", "jn": "John",
    "acts": "Acts",
    "rom": "Romans",
    "1cor": "1 Corinthians", "1 cor": "1 Corinthians",
    "2cor": "2 Corinthians", "2 cor": "2 Corinthians",
    "gal": "Galatians",
    "eph": "Ephesians",
    "phil": "Philippians",
    "col": "Colossians",
    "1thess": "1 Thessalonians", "1 thess": "1 Thessalonians",
    "2thess": "2 Thessalonians", "2 thess": "2 Thessalonians",
    "1tim": "1 Timothy", "1 tim": "1 Timothy",
    "2tim": "2 Timothy", "2 tim": "2 Timothy",
    "titus": "Titus", "tit": "Titus",
    "phlm": "Philemon", "philem": "Philemon",
    "heb": "Hebrews",
    "jas": "James", "jam": "James",
    "1pet": "1 Peter", "1 pet": "1 Peter",
    "2pet": "2 Peter", "2 pet": "2 Peter",
    "1john": "1 John", "1 john": "1 John", "1jn": "1 John",
    "2john": "2 John", "2 john": "2 John",
    "3john": "3 John", "3 john": "3 John",
    "jude": "Jude",
    "rev": "Revelation", "apoc": "Revelation",
    # ── KJV Apocrypha ──────────────────────────────────────────────────────
    "1esd": "1 Esdras", "1 esd": "1 Esdras",
    "2esd": "2 Esdras", "2 esd": "2 Esdras",
    "tob": "Tobit",
    "jdt": "Judith",
    "addesth": "Additions to Esther", "add esth": "Additions to Esther",
    "wis": "Wisdom of Solomon", "wisd": "Wisdom of Solomon", "wisdom": "Wisdom of Solomon",
    "sir": "Sirach", "ecclus": "Sirach",
    "bar": "Baruch",
    "epjer": "Epistle of Jeremiah", "ep jer": "Epistle of Jeremiah",
    "sg3": "Song of the Three Children",
    "sus": "Susanna",
    "bel": "Bel and the Dragon",
    "prmanas": "Prayer of Manasseh",
    "1macc": "1 Maccabees", "1 macc": "1 Maccabees",
    "2macc": "2 Maccabees", "2 macc": "2 Maccabees",
    # ── Brenton-only books ─────────────────────────────────────────────────
    "3macc": "3 Maccabees", "3 macc": "3 Maccabees",
    "4macc": "4 Maccabees", "4 macc": "4 Maccabees",
    "psssol": "Psalms of Solomon", "ps sol": "Psalms of Solomon", "pssol": "Psalms of Solomon",
    "odes": "Odes",
    "ps151": "Psalm 151", "psalm 151": "Psalm 151",
    "ps152": "Psalm 152", "psalm 152": "Psalm 152",
    "ps153": "Psalm 153", "psalm 153": "Psalm 153",
    "ps154": "Psalm 154", "psalm 154": "Psalm 154",
    "ps155": "Psalm 155", "psalm 155": "Psalm 155",
    # ── R.H. Charles ──────────────────────────────────────────────────────
    "enoch": "Book of Enoch", "1enoch": "Book of Enoch", "1 enoch": "Book of Enoch",
    "jub": "Book of Jubilees", "jubilees": "Book of Jubilees", "jub": "Book of Jubilees",
    # ── Apostolic Fathers (J.B. Lightfoot) ────────────────────────────────
    # 1 Clement — letter from the Roman church, ~96 AD
    "1clem": "1 Clement", "1 clem": "1 Clement", "1clement": "1 Clement",
    "i clem": "1 Clement", "i clement": "1 Clement",
    # 2 Clement — earliest surviving Christian homily, ~150 AD
    "2clem": "2 Clement", "2 clem": "2 Clement", "2clement": "2 Clement",
    "ii clem": "2 Clement", "ii clement": "2 Clement",
    # Ignatius of Antioch — seven letters, ~107 AD
    "ign eph": "Ignatius to the Ephesians",   "igneph": "Ignatius to the Ephesians",
    "ign mag": "Ignatius to the Magnesians",  "ignmag": "Ignatius to the Magnesians",
    "ign trall": "Ignatius to the Trallians", "igntrall": "Ignatius to the Trallians",
    "ign rom": "Ignatius to the Romans",      "ignrom": "Ignatius to the Romans",
    "ign phld": "Ignatius to the Philadelphians", "ignphld": "Ignatius to the Philadelphians",
    "ign smyrn": "Ignatius to the Smyrnaeans",    "ignsmyrn": "Ignatius to the Smyrnaeans",
    "ign pol": "Ignatius to Polycarp",        "ignpol": "Ignatius to Polycarp",
    # Polycarp
    "pol phil": "Polycarp to the Philippians", "polphil": "Polycarp to the Philippians",
    "pol": "Polycarp to the Philippians",      "polyp": "Polycarp to the Philippians",
    # Martyrdom of Polycarp
    "mart pol": "Martyrdom of Polycarp", "martpol": "Martyrdom of Polycarp",
    "mpol": "Martyrdom of Polycarp", "martyrdom": "Martyrdom of Polycarp",
    # Epistle of Barnabas
    "barn": "Epistle of Barnabas", "barnabas": "Epistle of Barnabas",
    "ep barn": "Epistle of Barnabas",
    # Didache (The Teaching of the Twelve Apostles)
    "did": "Didache", "didache": "Didache", "didach": "Didache",
    "teaching": "Didache",
    # Shepherd of Hermas
    "herm": "Shepherd of Hermas", "hermas": "Shepherd of Hermas",
    "shep herm": "Shepherd of Hermas", "shepherd": "Shepherd of Hermas",
    "herm vis": "Shepherd of Hermas", "hermvis": "Shepherd of Hermas",
    "herm man": "Shepherd of Hermas", "hermman": "Shepherd of Hermas",
    "herm sim": "Shepherd of Hermas", "hermsim": "Shepherd of Hermas",
    # ── Apocryphal Psalms ──────────────────────────────────────────────────
    "psalm 151": "Psalm 151", "ps 151": "Psalm 151",
    "psalm 152": "Psalm 152", "ps 152": "Psalm 152",
    "psalm 153": "Psalm 153", "ps 153": "Psalm 153",
    "psalm 154": "Psalm 154", "ps 154": "Psalm 154",
    "psalm 155": "Psalm 155", "ps 155": "Psalm 155",
    # ── Quran (Pickthall) ──────────────────────────────────────────────────
    "quran": "Quran", "qur": "Quran", "qran": "Quran",
    "sura": "Quran", "surah": "Quran",
    "koran": "Quran", "qur'an": "Quran",
    # ── Classical & Ancient Texts ───────────────────────────────────────────
    "golden verses": "Golden Verses of Pythagoras",
    "golden verses of pythagoras": "Golden Verses of Pythagoras",
    "gvp": "Golden Verses of Pythagoras",
    "pythagoras": "Golden Verses of Pythagoras",
    "orphic hymns": "Orphic Hymns",
    "orphic": "Orphic Hymns",
    "hymns of orpheus": "Orphic Hymns",
    "homeric hymns": "Homeric Hymns",
    "homeric": "Homeric Hymns",
    "corpus hermeticum": "Corpus Hermeticum",
    "hermeticum": "Corpus Hermeticum",
    "ch": "Corpus Hermeticum",
    "hermes": "Corpus Hermeticum",
    "asclepius": "Asclepius",
    "chaldaean oracles": "Chaldaean Oracles",
    "chaldean oracles": "Chaldaean Oracles",
    "oracles of zoroaster": "Chaldaean Oracles",
    "coz": "Chaldaean Oracles",
    "theogony": "Theogony",
    "hesiod": "Theogony",
    "hesiod theogony": "Theogony",
    "gathas": "Gathas",
    "gatha": "Gathas",
    "gathas of zarathushtra": "Gathas",
    "gathas of zarathustra": "Gathas",
    # Kitáb-i-Aqdas
    "kitab-i-aqdas": "Kitab-i-Aqdas",
    "kitab i aqdas": "Kitab-i-Aqdas",
    "aqdas": "Kitab-i-Aqdas",
    "kitab": "Kitab-i-Aqdas",
    "most holy book": "Kitab-i-Aqdas",
    # Ginza Rba
    "ginza rba": "Ginza Rba",
    "ginza": "Ginza Rba",
    "ginza rba - the canonical prayerbook of the mandaeans": "Ginza Rba",
    "mandaean prayerbook": "Ginza Rba",
    "ginza rabba": "Ginza Rba",
    # Mandaean Book of John
    "mandaean book of john": "Book of John",
    "mjohn": "Book of John",
    "mandaean john": "Book of John",
    "drasha d-yahya": "Book of John",
    "drasha dyahya": "Book of John",
    # Hymns of Proclus
    "proclus": "Proclus",
    "hymns of proclus": "Proclus",
    "proclus hymns": "Proclus",
    # Aeneid
    "aeneid": "Aeneid",
    "the aeneid": "Aeneid",
    "virgil": "Aeneid",
    "vergil": "Aeneid",
    # Plato dialogues
    "euthyphro": "Euthyphro",
    "apology": "Apology",
    "apology of socrates": "Apology",
    "crito": "Crito",
    "phaedo": "Phaedo",
    "cratylus": "Cratylus",
    "theaetetus": "Theaetetus",
    "sophist": "Sophist",
    "statesman": "Statesman",
    "politicus": "Statesman",
    "parmenides": "Parmenides",
    "philebus": "Philebus",
    "symposium": "Symposium",
    "phaedrus": "Phaedrus",
    "alcibiades i": "Alcibiades I",
    "alcibiades 1": "Alcibiades I",
    "first alcibiades": "Alcibiades I",
    "alcibiades ii": "Alcibiades II",
    "alcibiades 2": "Alcibiades II",
    "second alcibiades": "Alcibiades II",
    "hipparchus": "Hipparchus",
    "rival lovers": "Rival Lovers",
    "theages": "Theages",
    "charmides": "Charmides",
    "laches": "Laches",
    "lysis": "Lysis",
    "euthydemus": "Euthydemus",
    "protagoras": "Protagoras",
    "gorgias": "Gorgias",
    "meno": "Meno",
    "greater hippias": "Greater Hippias",
    "hippias major": "Greater Hippias",
    "lesser hippias": "Lesser Hippias",
    "hippias minor": "Lesser Hippias",
    "ion": "Ion",
    "menexenus": "Menexenus",
    "cleitophon": "Cleitophon",
    "clitophon": "Cleitophon",
    "republic": "Republic",
    "the republic": "Republic",
    "timaeus": "Timaeus",
    "critias": "Critias",
    "minos": "Minos",
    "laws": "Laws",
    "the laws": "Laws",
    "epinomis": "Epinomis",
    "letters": "Letters",
    "platonic letters": "Letters",
    "axiochus": "Axiochus",
    "on justice": "On Justice",
    "on virtue": "On Virtue",
    "demodocus": "Demodocus",
    "sisyphus": "Sisyphus",
    "eryxias": "Eryxias",
    "definitions": "Definitions",
    # ── Homer ──────────────────────────────────────────────────────────────────
    "iliad": "Iliad",
    "homer iliad": "Iliad",
    "odyssey": "Odyssey",
    "homer odyssey": "Odyssey",
    # ── Aristotle ──────────────────────────────────────────────────────────────
    "aristotle": "Nicomachean Ethics",  # default to most famous
    "nicomachean ethics": "Nicomachean Ethics",
    "nic eth": "Nicomachean Ethics",
    "en": "Nicomachean Ethics",
    "eudemian ethics": "Eudemian Ethics",
    "eud eth": "Eudemian Ethics",
    "ee": "Eudemian Ethics",
    "metaphysics": "Metaphysics",
    "met": "Metaphysics",
    "physics": "Physics",
    "phys": "Physics",
    "on the soul": "On the Soul",
    "de anima": "On the Soul",
    "politics": "Politics",
    "pol": "Politics",
    "rhetoric": "Rhetoric",
    "rhet": "Rhetoric",
    "poetics": "Poetics",
    "economics": "Economics",
    "categories": "Categories",
    "cat": "Categories",
    "on interpretation": "On Interpretation",
    "de int": "On Interpretation",
    "prior analytics": "Prior Analytics",
    "posterior analytics": "Posterior Analytics",
    "topics": "Topics",
    "on the heavens": "On the Heavens",
    "de caelo": "On the Heavens",
    "meteorology": "Meteorology",
    "on generation and corruption": "On Generation and Corruption",
    "history of animals": "History of Animals",
    "on the parts of animals": "On the Parts of Animals",
    "on the generation of animals": "On the Generation of Animals",
    "on memory": "On Memory and Reminiscence",
    "on memory and reminiscence": "On Memory and Reminiscence",
    "on dreams": "On Dreams",
    "on sleep": "On Sleep and Sleeplessness",
    "on prophesying by dreams": "On Prophesying by Dreams",
    "on sense": "On Sense and the Sensible",
    "on the motion of animals": "On the Motion of Animals",
    "on the gait of animals": "On the Gait of Animals",
    "athenian constitution": "Athenian Constitution",
    "ath const": "Athenian Constitution",
    "on longevity": "On Longevity and Shortness of Life",
    "on youth": "On Youth, Old Age, Life and Death",
    "on sophistical refutations": "On Sophistical Refutations",
    # ── Plotinus ───────────────────────────────────────────────────────────────
    "plotinus": "Enneads",
    "enneads": "Enneads",
    "rig veda": "Rig Veda", "rigveda": "Rig Veda", "rig": "Rig Veda",
    "yajur veda": "Yajur Veda", "yajurveda": "Yajur Veda", "yajur": "Yajur Veda",
    "sama veda": "Sama Veda", "samaveda": "Sama Veda", "sama": "Sama Veda",
    "atharva veda": "Atharva Veda", "atharvaveda": "Atharva Veda", "atharva": "Atharva Veda",
    "divine names": "Divine Names", "the divine names": "Divine Names",
    "mystical theology": "Mystical Theology", "mystic theology": "Mystical Theology",
    "heavenly hierarchy": "On the Heavenly Hierarchy",
    "on the heavenly hierarchy": "On the Heavenly Hierarchy",
    "celestial hierarchy": "On the Heavenly Hierarchy",
    "ecclesiastical hierarchy": "On the Ecclesiastical Hierarchy",
    "on the ecclesiastical hierarchy": "On the Ecclesiastical Hierarchy",
    "letters of dionysius": "Letters of Dionysius",
    "liturgy of st dionysius": "Liturgy of St. Dionysius",
    "liturgy of dionysius": "Liturgy of St. Dionysius",
    "the enneads": "Enneads",
    "six enneads": "Enneads",
    "enn": "Enneads",
    # ── Porphyry ───────────────────────────────────────────────────────────────
    "porphyry": "On Abstinence",  # default to longest work
    "on abstinence": "On Abstinence",
    "de abstinentia": "On Abstinence",
    "porphyry life of pythagoras": "Life of Pythagoras",
    "porphyry pythagoras": "Life of Pythagoras",
    "cave of the nymphs": "On the Cave of the Nymphs",
    "cave of nymphs": "On the Cave of the Nymphs",
    "de antro": "On the Cave of the Nymphs",
    "auxiliaries": "Auxiliaries to the Intelligibles",
    "sententiae": "Auxiliaries to the Intelligibles",
    "letter to marcella": "Letter to Marcella",
    "marcella": "Letter to Marcella",
    # ── Iamblichus ─────────────────────────────────────────────────────────────
    "iamblichus": "On the Mysteries",  # default to most famous
    "on the mysteries": "On the Mysteries",
    "de mysteriis": "On the Mysteries",
    "iamblichus mysteries": "On the Mysteries",
    "iamblichus life of pythagoras": "Life of Pythagoras",
    "iamblichus pythagoras": "Life of Pythagoras",
    # ── Philo ──────────────────────────────────────────────────────────────────
    "philo": "On the Creation",  # default
    "philo judaeus": "On the Creation",
    "on the creation": "On the Creation",
    "de opificio": "On the Creation",
    "allegorical interpretation": "Allegorical Interpretation I",
    "allegorical interpretation i": "Allegorical Interpretation I",
    "allegorical interpretation ii": "Allegorical Interpretation II",
    "allegorical interpretation iii": "Allegorical Interpretation III",
    "on the cherubim": "On the Cherubim",
    "on abraham": "On Abraham",
    "on joseph": "On Joseph",
    "on the life of moses": "On the Life of Moses I",
    "life of moses": "On the Life of Moses I",
    "the decalogue": "The Decalogue",
    "decalogue": "The Decalogue",
    "on the embassy to gaius": "On the Embassy to Gaius",
    "embassy to gaius": "On the Embassy to Gaius",
    "flaccus": "Flaccus",
    "every good man is free": "Every Good Man is Free",
    "on the contemplative life": "On the Contemplative Life",
    "questions on genesis": "Questions on Genesis I",
    "questions on genesis i": "Questions on Genesis I",
    "questions on genesis ii": "Questions on Genesis II",
    "questions on genesis iii": "Questions on Genesis III",
    # ── Josephus ───────────────────────────────────────────────────────────────
    "josephus": "Jewish Antiquities",  # default
    "jewish antiquities": "Jewish Antiquities",
    "antiquities": "Jewish Antiquities",
    "ant": "Jewish Antiquities",
    "jewish war": "Jewish War",
    "war": "Jewish War",
    "bj": "Jewish War",
    "against apion": "Against Apion",
    "apion": "Against Apion",
    "life of josephus": "Life",
    "josephus life": "Life",
    # ── Julian ─────────────────────────────────────────────────────────────────
    "julian": "Hymn to King Helios",  # default
    "emperor julian": "Hymn to King Helios",
    "julian the apostate": "Hymn to King Helios",
    "hymn to king helios": "Hymn to King Helios",
    "hymn to helios": "Hymn to King Helios",
    "oration to the sun": "Hymn to King Helios",
    "hymn to the mother of gods": "Hymn to the Mother of Gods",
    "hymn to the mother of the gods": "Hymn to the Mother of Gods",
    "hymn to cybele": "Hymn to the Mother of Gods",
    "against the galilaeans": "Against the Galilaeans",
    "against the galileans": "Against the Galilaeans",
    "against the christians": "Against the Galilaeans",
    "the caesars": "The Caesars",
    "caesars": "The Caesars",
    "symposium of the caesars": "The Caesars",
    # ── Sallustius ─────────────────────────────────────────────────────────────
    "sallustius": "On the Gods and the World",
    "sallust": "On the Gods and the World",
    "on the gods and the world": "On the Gods and the World",
    "on the gods": "On the Gods and the World",
    "peri theon": "On the Gods and the World",
    # ── Proclus (theology) ─────────────────────────────────────────────────────
    "theology of plato": "Theology of Plato",
    "platonic theology": "Theology of Plato",
    "proclus theology": "Theology of Plato",
    "elements of theology": "Elements of Theology",
    "stoicheiosis theologike": "Elements of Theology",
    "proclus elements": "Elements of Theology",
    # ── Hierocles ──────────────────────────────────────────────────────────────
    "hierocles": "Commentary on the Golden Verses",
    "commentary on the golden verses": "Commentary on the Golden Verses",
    "hierocles commentary": "Commentary on the Golden Verses",
    # ── Marinus ────────────────────────────────────────────────────────────────
    "marinus": "Life of Proclus",
    "life of proclus": "Life of Proclus",
    "marinus life of proclus": "Life of Proclus",
    "on happiness": "Life of Proclus",
    # ── Pythagorean Sentences ──────────────────────────────────────────────────
    "pythagorean sentences": "Select Sentences of Sextus the Pythagorean",
    "sentences of sextus": "Select Sentences of Sextus the Pythagorean",
    "sextus pythagorean": "Select Sentences of Sextus the Pythagorean",
    "sextus": "Select Sentences of Sextus the Pythagorean",
    "demophilus": "Pythagorean Sentences of Demophilus",
    "sentences of demophilus": "Pythagorean Sentences of Demophilus",
    "democrates": "Golden Sentences of Democrates",
    "golden sentences": "Golden Sentences of Democrates",
    "sentences of democrates": "Golden Sentences of Democrates",
    "pythagorean sentences from stobaeus": "Pythagorean Sentences from Stobaeus",
    "stobaeus pythagorean": "Pythagorean Sentences from Stobaeus",
    "symbols of pythagoras": "Symbols of Pythagoras",
    "pythagorean symbols": "Symbols of Pythagoras",
    "similitudes of demophilus": "Similitudes of Demophilus",
    "pythagorean sentences from iamblichus": "Pythagorean Sentences from Iamblichus",
    # ── Porphyry additions ─────────────────────────────────────────────────────
    "life of plotinus": "Life of Plotinus",
    "porphyry life of plotinus": "Life of Plotinus",
    # 36 Lessons of Vivec
    "vivec": "Vivec",
    "lessons of vivec": "Vivec",
    "36 lessons of vivec": "Vivec",
    "sermon": "Vivec",
    "sermons of vivec": "Vivec",
    # Delphi
    "delphic maxims": "Delphic Maxims",
    "delphi maxims": "Delphic Maxims",
    "maxims": "Delphic Maxims",
    "delphic oracles": "Oracular Statements",
    "delphi oracles": "Oracular Statements",
    "oracular statements": "Oracular Statements",
    "pythia": "Oracular Statements",
    "pythian oracles": "Oracular Statements",
    # ── Mishnah (via Sefaria — these are handled as live lookups, ──────────
    # aliases here just help _suggest_books find them)
    "mishnah": "_sefaria_mishnah", "mishna": "_sefaria_mishnah",
    "m.": "_sefaria_mishnah",
    # ── Talmud Bavli (via Sefaria) ─────────────────────────────────────────
    "talmud": "_sefaria_talmud", "gemara": "_sefaria_talmud",
    "bavli": "_sefaria_talmud", "talmud bavli": "_sefaria_talmud",
    "bt": "_sefaria_talmud",
    # ── Zohar (via Sefaria) ────────────────────────────────────────────────
    "zohar": "_sefaria_zohar", "the zohar": "_sefaria_zohar",
    "sefer hazohar": "_sefaria_zohar",
    # ── Hadith (via fawazahmed0 CDN) ───────────────────────────────────────
    "hadith": "_hadith", "hadith bukhari": "_hadith",
    "bukhari": "_hadith", "sahih bukhari": "_hadith",
    "muslim": "_hadith", "sahih muslim": "_hadith",
    "abu dawud": "_hadith", "tirmidhi": "_hadith",
    "nasai": "_hadith", "ibn majah": "_hadith",
    "muwatta": "_hadith", "nawawi": "_hadith", "nawawi 40": "_hadith",
    "1ne": "1 Nephi", "1 ne": "1 Nephi", "1nep": "1 Nephi",
    "2ne": "2 Nephi", "2 ne": "2 Nephi", "2nep": "2 Nephi",
    "jacob": "Jacob",
    "enos": "Enos",
    "jarom": "Jarom",
    "omni": "Omni",
    "wom": "Words of Mormon",
    "mosiah": "Mosiah",
    "alma": "Alma",
    "hel": "Helaman",
    "3ne": "3 Nephi", "3 ne": "3 Nephi",
    "4ne": "4 Nephi", "4 ne": "4 Nephi",
    "morm": "Mormon",
    "ether": "Ether",
    "moro": "Moroni",
    # ── LDS: D&C ──────────────────────────────────────────────────────────
    "dc": "Doctrine and Covenants", "d&c": "Doctrine and Covenants",
    "d and c": "Doctrine and Covenants",
    # ── LDS: Pearl of Great Price ──────────────────────────────────────────
    "moses": "Moses",
    "abr": "Abraham",
    "jsm": "Joseph Smith—Matthew", "js-m": "Joseph Smith—Matthew",
    "jsh": "Joseph Smith—History", "js-h": "Joseph Smith—History",
    "aof": "Articles of Faith",
}

# Priority order when the same book name exists in multiple corpora
# (first match wins unless the user specifies a corpus)
CORPUS_PRIORITY = ["kjv", "lds", "brenton", "charles", "apostolic_fathers", "quran", "classical", "jewish", "bahai", "gnostic", "dharmic", "norse"]


class ScriptureLookup:
    def __init__(self, data_dir: Path = DATA_DIR):
        self.data_dir = data_dir
        # corpus_name → { book_name → { chapter_str → { verse_str → text } } }
        self._data: dict[str, dict] = {}
        # book_name (lower) → (corpus_name, canonical_name)
        self._book_index: dict[str, tuple[str, str]] = {}
        # canonical book_name → source string for footer display
        self._book_sources: dict[str, str] = {}
        self._load_all()

    # ── Loading ────────────────────────────────────────────────────────────────

    def _load_all(self):
        corpus_dirs = {
            "kjv":     ["kjv_canon.json", "kjv_apocrypha.json"],
            "lds":     ["book_of_mormon.json", "doctrine_and_covenants.json", "pearl_of_great_price.json"],
            "brenton": ["brenton_extras.json"],
            "charles": ["book_of_enoch.json", "book_of_jubilees.json"],
            "apostolic_fathers": [
                "1_clement.json",
                "2_clement.json",
                "ignatius_ephesians.json",
                "ignatius_magnesians.json",
                "ignatius_trallians.json",
                "ignatius_romans.json",
                "ignatius_philadelphians.json",
                "ignatius_smyrnaeans.json",
                "ignatius_polycarp.json",
                "polycarp_philippians.json",
                "martyrdom_of_polycarp.json",
                "epistle_of_barnabas.json",
                "didache.json",
                "shepherd_of_hermas.json",
                "divine_names.json",
                "mystical_theology.json",
                "on_the_heavenly_hierarchy.json",
                "on_the_ecclesiastical_hierarchy.json",
                "letters_of_dionysius.json",
                "liturgy_of_st_dionysius.json",
            ],
            "quran": ["quran_pickthall.json"],
            "classical": [
                "golden_verses.json",
                "orphic_hymns.json",
                "homeric_hymns.json",
                "corpus_hermeticum.json",
                "asclepius.json",
                "chaldaean_oracles.json",
                "hesiod_theogony.json",
                "gathas.json",
                "vivec_sermons.json",
                "proclus.json",
                "delphi.json",
                "aeneid.json",
                "plato.json",
                "homer.json",
                "plotinus.json",
                "porphyry.json",
                "iamblichus.json",
                "aristotle_perseus.json",
                "aristotle_mit.json",
                "julian.json",
                "sallustius.json",
                "proclus_theology.json",
                "hierocles.json",
                "marinus.json",
                "pythagorean_sentences.json",
                "divine_names.json",
                "mystical_theology.json",
                "on_the_heavenly_hierarchy.json",
                "on_the_ecclesiastical_hierarchy.json",
            ],
            "jewish": [
                "josephus.json",
                "philo.json",
            ],
            "bahai": [
                "kitab_i_aqdas.json",
            ],
            "gnostic": [
                "ginza_rba.json",
                "mandaean_book_of_john.json",
            ],
            "norse": [
                "poetic_edda.json",
            ],
            "dharmic": [
                "rig_veda.json",
                "yajur_veda.json",
                "sama_veda.json",
                "atharva_veda.json",
            ],
        }
        for corpus, filenames in corpus_dirs.items():
            self._data.setdefault(corpus, {})
            for fname in filenames:
                path = self.data_dir / corpus / fname
                if not path.exists():
                    print(f"[WARN] Missing data file: {path}")
                    continue
                with open(path, encoding="utf-8") as f:
                    payload = json.load(f)
                books = payload.get("books", {})
                self._data[corpus].update(books)
                # Store per-book source string for footer display
                file_source = payload.get("source", "")
                if file_source:
                    for book_name in books:
                        self._book_sources[book_name] = file_source
        # Build book index respecting priority
        for corpus in CORPUS_PRIORITY:
            for book_name in self._data.get(corpus, {}):
                key = book_name.lower()
                if key not in self._book_index:
                    self._book_index[key] = (corpus, book_name)

    # ── Public API ─────────────────────────────────────────────────────────────

    def random_verse(self) -> dict:
        """Pick a completely random verse from any loaded corpus."""
        import random as _random
        # Build a flat list of (corpus, book, chapter, verse) tuples
        # Skip Mishnah/Talmud/Zohar/Hadith (live API) and Vivec (sermon-length)
        SKIP_BOOKS = {"Vivec"}
        candidates = []
        for corpus, books in self._data.items():
            for book, chapters in books.items():
                if book in SKIP_BOOKS:
                    continue
                for chap, verses in chapters.items():
                    for verse in verses.keys():
                        candidates.append((corpus, book, chap, verse))
        if not candidates:
            return {"found": False, "error": "No verse data loaded.", "suggestions": []}

        corpus, book, chap, verse = _random.choice(candidates)
        text = self._data[corpus][book][chap][verse]
        source = self._book_sources.get(book, book)
        ref = f"{book} {chap}:{verse}"
        return {
            "found": True,
            "reference": ref,
            "text": text,
            "source": source,
            "book": book,
            "chapter": chap,
            "verse": verse,
        }

    def random_verse_from_book(self, book_raw: str) -> dict:
        """Pick a random verse from a specific book."""
        import random as _random
        corpus, canon_book = self._resolve_book(book_raw)
        if canon_book is None:
            return {
                "found": False,
                "error": f"Unknown book: **{book_raw}**",
                "suggestions": self._suggest_books(book_raw),
            }
        chapters = self._data[corpus].get(canon_book, {})
        if not chapters:
            return {"found": False, "error": f"No data found for **{canon_book}**.", "suggestions": []}

        chap = _random.choice(list(chapters.keys()))
        verses = chapters[chap]
        verse = _random.choice(list(verses.keys()))
        text = verses[verse]
        source = self._book_sources.get(canon_book, canon_book)
        return {
            "found": True,
            "reference": f"{canon_book} {chap}:{verse}",
            "text": text,
            "source": source,
            "book": canon_book,
            "chapter": chap,
            "verse": verse,
        }

    def random_verse_from_books(self, book_list: list[str]) -> dict:
        """Pick a random verse from a list of book names."""
        import random as _random
        candidates = []
        for book_name in book_list:
            for corpus in self._data.values():
                if book_name in corpus:
                    for chap, verses in corpus[book_name].items():
                        for verse in verses.keys():
                            candidates.append((book_name, corpus, chap, verse))
                    break
        if not candidates:
            return {"found": False, "error": "No verse data found for those books.", "suggestions": []}
        book_name, corpus, chap, verse = _random.choice(candidates)
        text = corpus[book_name][chap][verse]
        source = self._book_sources.get(book_name, book_name)
        return {
            "found": True,
            "reference": f"{book_name} {chap}:{verse}",
            "text": text,
            "source": source,
            "book": book_name,
            "chapter": chap,
            "verse": verse,
        }


    def corpora_names(self) -> list[str]:
        return [c for c in CORPUS_PRIORITY if self._data.get(c)]

    def chapter_count(self, book_name: str) -> int | None:
        """Return number of chapters for a locally-loaded book, or None."""
        for corpus in self._data.values():
            if book_name in corpus:
                return len(corpus[book_name])
        return None

    def section_books(self, book_list: list[str]) -> list[tuple[str, int | None]]:
        """Return [(book_name, chapter_count_or_None)] for a list of books,
        filtered to only those actually loaded (or always-available via API)."""
        loaded = {name for books in self._data.values() for name in books}
        mishnah_available = {
            v.replace("Mishnah_", "").replace("_", " ")
            for v in MISHNAH_TRACTATES.values()
        }
        talmud_available = set(TALMUD_TRACTATES.values())
        hadith_available  = set(COLLECTION_DISPLAY.values())
        always_available  = {"Zohar"} | mishnah_available | talmud_available | hadith_available

        result = []
        for b in book_list:
            if b in loaded or b in always_available:
                result.append((b, self.chapter_count(b)))
        return result

    def get_verse(self, reference: str) -> dict:
        """
        Parse a free-form reference like "John 3:16" or "D&C 76:22-24"
        and return the verse text.
        """
        ref = reference.strip()

        # ── Talmud: try early before generic parsing strips the daf letter ──
        # "Talmud Berakhot 2a:3", "Gemara Shabbat 31a", "Berakhot 2a:3" all
        # contain a daf (digit+a/b). parse_talmud_ref handles all these forms.
        # BUT: check for Plato first since Stephanus refs also end in letter+digit.
        stephanus_result = self._try_stephanus(ref)
        if stephanus_result is not None:
            return stephanus_result

        if re.search(r"\d+[ab]", ref, re.IGNORECASE):
            talmud_result = get_talmud(ref)
            if talmud_result is not None:
                return talmud_result

        # ── Zohar: "Zohar 1:1a:3" or bare "Zohar" ────────────────────────────
        if re.match(r"^(?:the\s+)?zohar\b", ref, re.IGNORECASE):
            zohar_result = self._try_zohar_raw(ref)
            if zohar_result is not None:
                return zohar_result
            return {
                "found": False,
                "error": "Could not fetch that Zohar reference.\nFormat: `Zohar Bereshit 5` or just `Zohar` for random.",
                "suggestions": []
            }
        # ── Delphi 1:N (maxims) / Delphi 2:N (oracular statements) ──────────
        delphi_m = re.match(r"^delphi\s+([12]):(\d+)$", ref, re.IGNORECASE)
        if delphi_m:
            sub, num = delphi_m.group(1), delphi_m.group(2)
            book = "Delphic Maxims" if sub == "1" else "Oracular Statements"
            corpus = "classical"
            chap_data = self._data.get(corpus, {}).get(book, {}).get(num)
            if chap_data is None:
                max_n = max((int(k) for k in self._data.get(corpus, {}).get(book, {})), default=0)
                return {"found": False, "error": f"**{book}** has no entry {num}. (Max: {max_n})", "suggestions": []}
            text = chap_data.get("1", "")
            return {"found": True, "reference": f"Delphi {sub}:{num}", "text": text,
                    "source": book, "book": book, "chapter": int(num), "verse": 1}

        parsed = self._parse_reference(ref)
        if parsed is None:
            return {
                "found": False,
                "error": f'Could not parse reference: **{ref}**\nTry: `Book Chapter:Verse`',
                "suggestions": self._suggest_books(ref),
            }

        book_raw, chapter, verse_start, verse_end = parsed
        corpus, canon_book = self._resolve_book(book_raw)

        # ── Kitab-i-Aqdas: paragraph-based, ignore verse number ──────────────
        if canon_book == "Kitab-i-Aqdas":
            chap_data = self._data.get("bahai", {}).get("Kitab-i-Aqdas", {}).get(str(chapter))
            if chap_data is None:
                max_p = max((int(k) for k in self._data.get("bahai", {}).get("Kitab-i-Aqdas", {})), default=190)
                return {"found": False, "error": f"**Kitáb-i-Aqdas** has no paragraph {chapter}. (Max: {max_p})", "suggestions": []}
            text = chap_data.get("1", "")
            return {"found": True, "reference": f"Kitáb-i-Aqdas ¶{chapter}",
                    "text": text, "source": "Kitáb-i-Aqdas — Bahá'u'lláh (1992)",
                    "book": "Kitab-i-Aqdas", "chapter": chapter, "verse": 1}
        if canon_book is None:
            # Try Sefaria (Mishnah) as fallback
            sefaria_result = self._try_sefaria(book_raw, chapter, verse_start, verse_end)
            if sefaria_result is not None:
                return sefaria_result
            # Try Hadith
            hadith_result = self._try_hadith(ref)
            if hadith_result is not None:
                return hadith_result
            return {
                "found": False,
                "error": f'Unknown book: **{book_raw}**',
                "suggestions": self._suggest_books(book_raw),
            }

        chap_key = chapter if isinstance(chapter, str) else str(chapter)
        chap_data = self._data[corpus].get(canon_book, {}).get(chap_key)
        if chap_data is None:
            def _chap_sort(k):
                try: return [int(x) for x in k.split('.')]
                except: return [0]
            all_keys = sorted(self._data[corpus][canon_book].keys(), key=_chap_sort)
            max_chap = all_keys[-1] if all_keys else "0"
            return {
                "found": False,
                "error": f'**{canon_book}** has no chapter {chapter}. (Max: {max_chap})',
                "suggestions": [],
            }

        source_map = {
            "kjv":               "King James Bible (with Apocrypha)",
            "lds":               "LDS Standard Works",
            "brenton":           "Brenton Septuagint",
            "charles":           "R.H. Charles",
            "apostolic_fathers": "Apostolic Fathers (J.B. Lightfoot)",
            "quran":             "The Glorious Quran (Pickthall)",
            "classical":         "Classical & Ancient Texts",
            "jewish":            "Jewish Hellenistic Texts",
            "bahai":             "Bahá'í Writings",
            "gnostic":           "Gnostic & Esoteric Texts",
            "dharmic":           "Dharmic Scriptures Team (2008)",
            "norse":            "Trans. Henry Adams Bellows (1923)",
        }

        # Determine source string — prefer per-book source, fall back to corpus map
        source = self._book_sources.get(canon_book, source_map.get(corpus, corpus))

        # Whole chapter requested (no verse number given)
        if verse_start is None:
            sorted_verses = sorted(chap_data.keys(), key=lambda x: (int(re.sub(r'\D', '', x) or 0), x))
            texts = [f"**[{v}]** {chap_data[v]}" for v in sorted_verses]

            # Split into pages of 20 verses
            PAGE_SIZE = 15
            pages = ["\n".join(texts[i:i+PAGE_SIZE]) for i in range(0, len(texts), PAGE_SIZE)]

            return {
                "found": True,
                "reference": f"{canon_book} {chapter}",
                "text": "\n".join(texts),
                "source": source,
                "pages": pages,   # present if chapter needs pagination
            }

        if verse_end is None:
            verse_end = verse_start

        texts = []
        for v in range(verse_start, verse_end + 1):
            val = chap_data.get(str(v))
            if val:
                t = val if isinstance(val, str) else val.get("1", "")
                if t:
                    texts.append(f"**[{v}]** {t}")

        if not texts:
            max_v = max((int(k) for k in chap_data), default=0)
            return {
                "found": False,
                "error": f'Verse {verse_start} not found in {canon_book} {chapter}. (Max verse: {max_v})',
                "suggestions": [],
            }

        verse_label = f"{verse_start}" if verse_start == verse_end else f"{verse_start}–{verse_end}"
        return {
            "found": True,
            "reference": f"{canon_book} {chapter}:{verse_label}",
            "text": "\n".join(texts),
            "source": source,
        }

    def search(self, query: str, limit: int = 5) -> list[dict]:
        """Full-text search across all loaded data."""
        q = query.lower()
        results = []
        for corpus, books in self._data.items():
            for book, chapters in books.items():
                for chap, verses in chapters.items():
                    for verse, text in verses.items():
                        if q in text.lower():
                            results.append({
                                "reference": f"{book} {chap}:{verse}",
                                "text": text,
                                "source": corpus,
                            })
                            if len(results) >= limit:
                                return results
        return results

    def _try_sefaria(self, book_raw: str, chapter: int, verse_start, verse_end) -> Optional[dict]:
        """
        Try Mishnah, Talmud, or Zohar via Sefaria.
        Returns a result dict if found, or None.
        """
        book_lc = book_raw.lower().strip()

        # ── Zohar ─────────────────────────────────────────────────────────────
        # User types: "Zohar 1:1a:3"  → book_raw="Zohar 1", chapter parsed weirdly
        # Better: detect "zohar" prefix and re-parse the full original string
        if book_lc in ("zohar", "the zohar", "sefer hazohar"):
            # chapter = volume (1–3), verse_start = daf number (but daf needs a/b suffix)
            # This case is handled below in get_verse via _try_zohar_raw
            return None  # handled by _try_zohar_raw

        # ── Talmud — detect daf-style chapter ─────────────────────────────────
        # "Talmud Berakhot 2a:3" → _parse_reference gives book="Talmud Berakhot 2a", chapter=3
        # We need to detect "2a" at end of book_raw and re-route
        talmud_in_book = re.match(
            r"^(.*?)\s+(\d+[ab])$", book_raw, re.IGNORECASE
        )
        if talmud_in_book:
            tractate_raw = talmud_in_book.group(1).strip()
            daf          = talmud_in_book.group(2).lower()
            # Strip "talmud"/"gemara" prefix from tractate_raw if present
            tractate_raw = re.sub(
                r"^(?:talmud|gemara|bavli|bt)\s+", "", tractate_raw,
                flags=re.IGNORECASE
            ).strip()
            tractate = resolve_talmud_tractate(tractate_raw)
            if tractate:
                from sefaria_lookup import fetch_talmud
                # chapter here is the section number (from "2a:3" → chapter=3)
                section = verse_start if verse_start else chapter
                return fetch_talmud(tractate, daf, section if verse_start else None)

        # ── Mishnah ────────────────────────────────────────────────────────────
        index = resolve_tractate(book_lc)
        if index is None:
            return None

        if verse_start is None:
            return fetch_mishnah_chapter(index, chapter)
        else:
            end = verse_end if verse_end else verse_start
            if verse_start == end:
                return fetch_mishnah(index, chapter, verse_start)
            else:
                texts = []
                for v in range(verse_start, end + 1):
                    r = fetch_mishnah(index, chapter, v)
                    if r["found"]:
                        texts.append(f"**[{v}]** {r['text']}")
                if texts:
                    index_display = index.replace("Mishnah_", "").replace("_", " ")
                    v_label = f"{verse_start}–{end}"
                    return {
                        "found": True,
                        "reference": f"Mishnah {index_display} {chapter}:{v_label}",
                        "text": "\n".join(texts),
                        "source": r.get("source", "Mishnah (via Sefaria)"),
                    }
                return None

    def _try_zohar_raw(self, raw_ref: str) -> Optional[dict]:
        """
        Try to parse and fetch a Zohar reference.
        Handles: "Zohar Bereshit 5", "Zohar Introduction", bare "Zohar" for random.
        """
        import random as _random
        stripped = re.sub(r"^(?:the\s+)?zohar\s*", "", raw_ref, flags=re.IGNORECASE).strip()

        # Bare "Zohar" — pick a random parasha and segment
        if not stripped:
            from sefaria_lookup import ZOHAR_PARASHOT, fetch_zohar
            parasha, max_seg = _random.choice(ZOHAR_PARASHOT)
            segment = _random.randint(1, min(max_seg, 30))
            result = fetch_zohar(parasha, segment)
            if not result.get("found"):
                result = fetch_zohar(parasha, 1)
            return result if result.get("found") else None

        from sefaria_lookup import parse_zohar_ref, fetch_zohar
        parsed = parse_zohar_ref("zohar " + stripped)
        if parsed is None:
            return None
        parasha, segment = parsed
        return fetch_zohar(parasha, segment)

    def _try_hadith(self, raw_ref: str) -> Optional[dict]:
        """Try to resolve the full raw reference as a hadith."""
        return get_hadith(raw_ref)

    def _try_stephanus(self, raw_ref: str) -> Optional[dict]:
        """
        Try to resolve a Plato Stephanus reference.
        Formats accepted:
          "Apology 17a"         → Apology, section 17a
          "Republic 514a"       → Republic, section 514a (book-qualified key tried)
          "Republic 7.514a"     → Republic, section 7.514a
          "Republic 7.514"      → Republic, chapter 7, section 514 (any subsection)
        Returns None if this doesn't look like a Plato ref.
        """
        # Pattern: <words> <optional_book_num.><stephanus_page><optional_letter>
        # e.g. "Apology 17a", "Republic 7.514a", "Republic 514"
        m = re.match(
            r"^(.+?)\s+(?:(\d+)\.)?(\d+)([a-e]?)$",
            raw_ref.strip(),
            re.IGNORECASE,
        )
        if not m:
            return None

        book_raw = m.group(1).strip()
        book_num = m.group(2)   # e.g. "7" for Republic 7.514a
        page     = m.group(3)   # e.g. "514"
        section  = m.group(4).lower()  # e.g. "a"

        # Resolve book name
        corpus, canon_book = self._resolve_book(book_raw)
        if canon_book is None:
            return None

        # Only applies to Plato dialogues
        plato_books = set(ALIASES[k] for k in ALIASES if k in (
            "euthyphro","apology","crito","phaedo","cratylus","theaetetus",
            "sophist","statesman","parmenides","philebus","symposium","phaedrus",
            "alcibiades i","alcibiades ii","hipparchus","rival lovers","theages",
            "charmides","laches","lysis","euthydemus","protagoras","gorgias",
            "meno","greater hippias","lesser hippias","ion","menexenus","cleitophon",
            "republic","timaeus","critias","minos","laws","epinomis","letters",
            "axiochus","on justice","on virtue","demodocus","sisyphus","eryxias",
            "definitions",
        ))
        if canon_book not in plato_books:
            return None

        chap_data = self._data.get(corpus, {}).get(canon_book, {})
        if not chap_data:
            return None

        # Build candidate keys to try, in priority order
        candidates = []
        if book_num and section:
            candidates.append(f"{book_num}.{page}{section}")
        if book_num:
            for s in "abcde":
                candidates.append(f"{book_num}.{page}{s}")
        if section:
            candidates.append(f"{page}{section}")
        for s in "abcde":
            candidates.append(f"{page}{s}")
        candidates.append(page)

        for key in candidates:
            if key in chap_data:
                val = chap_data[key]
                # verse dict wrapper {"1": text} or bare string
                if isinstance(val, dict):
                    text = val.get("1", next(iter(val.values()), ""))
                else:
                    text = val
                source = self._book_sources.get(canon_book, "Plato (trans. Jowett)")
                return {
                    "found": True,
                    "reference": f"{canon_book} {key}",
                    "text": text,
                    "source": source,
                    "book": canon_book,
                    "chapter": key,
                    "verse": 1,
                }

        # Section not found — report closest available
        available = sorted(chap_data.keys())[:5]
        return {
            "found": False,
            "error": f"**{canon_book} {book_num+'.' if book_num else ''}{page}{section}** not found. Available sections start at: {', '.join(available)}",
            "suggestions": [],
        }

    # ── Parsing ────────────────────────────────────────────────────────────────

    def _parse_reference(self, ref: str):
        """
        Split a reference string into (book, chapter, verse_start, verse_end).
        Handles plain refs like 'John 3:16' and dotted refs like
        'Rig Veda 10.121:9', 'Rig Veda 10.121.9', 'Sama Veda 1.1.1.1:3'.
        For dotted refs without a colon, the last dot-segment is the verse number.
        """
        ref = ref.strip()

        # ── Dotted chapter with explicit colon: "Book N.N.N:V" ───────────────
        m_dot_colon = re.match(
            r"^(.*)\s+(\d+(?:\.\d+)+):(\d+)(?:\s*[-–—]\s*(\d+))?$",
            ref, re.UNICODE)
        if m_dot_colon:
            book = m_dot_colon.group(1).strip()
            if book:
                return (book, m_dot_colon.group(2),
                        int(m_dot_colon.group(3)),
                        int(m_dot_colon.group(4)) if m_dot_colon.group(4) else None)

        # ── Dotted chapter without colon: "Book N.N.N" → chapter=N.N, verse=N ─
        m_dot_bare = re.match(
            r"^(.*)\s+(\d+(?:\.\d+)+)$",
            ref, re.UNICODE)
        if m_dot_bare:
            book = m_dot_bare.group(1).strip()
            dotted = m_dot_bare.group(2)          # e.g. "10.121.9"
            if book and '.' in dotted:
                last_dot = dotted.rfind('.')
                chapter = dotted[:last_dot]        # "10.121"
                verse = int(dotted[last_dot+1:])   # 9
                return book, chapter, verse, None

        m = re.match(
            r"^(.*)\s+(\d+)(?::(\d+)(?:\s*[-–—]\s*(\d+))?)?$",
            ref,
            re.UNICODE,
        )
        if not m:
            return None

        book = m.group(1).strip()
        chapter = int(m.group(2))
        verse_start = int(m.group(3)) if m.group(3) else None  # None = whole chapter
        verse_end = int(m.group(4)) if m.group(4) else None

        if not book:
            return None

        # Special case: "Psalm 151" through "Psalm 155" are standalone books,
        # not chapters of KJV Psalms. Rewrite so the book name includes the number.
        if book.lower() in ("psalm", "psalms") and 151 <= chapter <= 155:
            book = f"Psalm {chapter}"
            chapter = chapter   # chapter key within that book equals the psalm number
            # verse_start stays as-is

        return book, chapter, verse_start, verse_end

    def _resolve_book(self, raw: str) -> tuple[Optional[str], Optional[str]]:
        """Return (corpus, canonical_book_name) or (None, None)."""
        key = raw.lower().strip()
        # 1. Direct alias lookup
        if key in ALIASES:
            canon = ALIASES[key]
            entry = self._book_index.get(canon.lower())
            if entry:
                return entry
        # 2. Direct name lookup (case-insensitive)
        entry = self._book_index.get(key)
        if entry:
            return entry
        # 3. Fuzzy match on alias values + book index keys
        candidates = list(ALIASES.values()) + [v[1] for v in self._book_index.values()]
        matches = get_close_matches(raw, candidates, n=1, cutoff=0.7)
        if matches:
            canon = matches[0]
            entry = self._book_index.get(canon.lower())
            if entry:
                return entry
        return None, None

    def _suggest_books(self, raw: str) -> list[str]:
        local_candidates = [v[1] for v in self._book_index.values()]
        mishnah_candidates = [
            v.replace("Mishnah_", "").replace("_", " ")
            for v in MISHNAH_TRACTATES.values()
        ]
        talmud_candidates = list(TALMUD_TRACTATES.values())
        hadith_candidates = list(COLLECTION_DISPLAY.values())
        all_candidates = local_candidates + mishnah_candidates + talmud_candidates + hadith_candidates
        return get_close_matches(raw, all_candidates, n=3, cutoff=0.4)


# ── Douay-Rheims Bible ─────────────────────────────────────────────────────────

# Maps KJV canonical book names → DR book names where they differ
_KJV_TO_DR: dict[str, str] = {
    "Joshua":           "Josue",
    "1 Samuel":         "1 Kings",
    "2 Samuel":         "2 Kings",
    "1 Kings":          "3 Kings",
    "2 Kings":          "4 Kings",
    "1 Chronicles":     "1 Paralipomenon",
    "2 Chronicles":     "2 Paralipomenon",
    "Ezra":             "1 Esdras",
    "Nehemiah":         "2 Esdras",
    "Tobit":            "Tobias",
    "Song of Solomon":  "Canticles",
    "Song of Songs":    "Canticles",
    "Isaiah":           "Isaias",
    "Jeremiah":         "Jeremias",
    "Ezekiel":          "Ezechiel",
    "Hosea":            "Osee",
    "Obadiah":          "Abdias",
    "Jonah":            "Jonas",
    "Micah":            "Micheas",
    "Habakkuk":         "Habacuc",
    "Zephaniah":        "Sophonias",
    "Haggai":           "Aggeus",
    "Zechariah":        "Zacharias",
    "Malachi":          "Malachias",
    "1 Maccabees":      "1 Machabees",
    "2 Maccabees":      "2 Machabees",
    "Revelation":       "Apocalypse",
}

# DR-specific names users might type directly (e.g. "Josue 1:1 DRB")
_DR_USER_ALIASES: dict[str, str] = {
    "josue": "Josue",
    "1 paralipomenon": "1 Paralipomenon",
    "2 paralipomenon": "2 Paralipomenon",
    "paralipomenon": "1 Paralipomenon",
    "1 esdras": "1 Esdras",
    "2 esdras": "2 Esdras",
    "tobias": "Tobias",
    "canticles": "Canticles",
    "canticle of canticles": "Canticles",
    "isaias": "Isaias",
    "jeremias": "Jeremias",
    "ezechiel": "Ezechiel",
    "osee": "Osee",
    "abdias": "Abdias",
    "jonas": "Jonas",
    "micheas": "Micheas",
    "habacuc": "Habacuc",
    "sophonias": "Sophonias",
    "aggeus": "Aggeus",
    "zacharias": "Zacharias",
    "malachias": "Malachias",
    "1 machabees": "1 Machabees",
    "2 machabees": "2 Machabees",
    "apocalypse": "Apocalypse",
    "3 kings": "3 Kings",
    "4 kings": "4 Kings",
}

# DRB translation suffixes users can append to a reference
DRB_SUFFIXES = {"drb", "drv", "dr", "douay", "douay-rheims", "douay rheims"}

_drb_data: Optional[dict] = None

# ── Bible section book lists (used by !verse Bible shortcuts) ─────────────────

BIBLE_OT = [
    "Genesis","Exodus","Leviticus","Numbers","Deuteronomy","Joshua",
    "Judges","Ruth","1 Samuel","2 Samuel","1 Kings","2 Kings",
    "1 Chronicles","2 Chronicles","Ezra","Nehemiah","Esther","Job",
    "Psalms","Proverbs","Ecclesiastes","Song of Solomon","Isaiah",
    "Jeremiah","Lamentations","Ezekiel","Daniel","Hosea","Joel",
    "Amos","Obadiah","Jonah","Micah","Nahum","Habakkuk","Zephaniah",
    "Haggai","Zechariah","Malachi",
]
BIBLE_NT = [
    "Matthew","Mark","Luke","John","Acts","Romans",
    "1 Corinthians","2 Corinthians","Galatians","Ephesians",
    "Philippians","Colossians","1 Thessalonians","2 Thessalonians",
    "1 Timothy","2 Timothy","Titus","Philemon","Hebrews","James",
    "1 Peter","2 Peter","1 John","2 John","3 John","Jude","Revelation",
]
BIBLE_APOCRYPHA = [
    "1 Esdras","2 Esdras","Tobit","Judith","Additions to Esther",
    "Wisdom of Solomon","Sirach","Baruch","Epistle of Jeremiah",
    "Song of the Three Children","Susanna","Bel and the Dragon",
    "Prayer of Manasseh","1 Maccabees","2 Maccabees",
]


def _load_drb() -> Optional[dict]:
    global _drb_data
    if _drb_data is None:
        path = Path(__file__).parent / "data" / "drb.json"
        if path.exists():
            _drb_data = json.loads(path.read_text(encoding="utf-8"))
    return _drb_data


def get_verse_drb(reference: str) -> dict:
    """
    Look up a verse in the Douay-Rheims Bible.
    Reference should already have the DRB suffix stripped.
    Accepts KJV book names and DR-specific names.
    Returns same dict format as ScriptureLookup.get_verse().
    """
    data = _load_drb()
    if data is None:
        return {"found": False, "error": "Douay-Rheims data not found (drb.json missing).", "suggestions": []}

    # Parse reference
    m = re.match(
        r"^((?:\d\s*)?[A-Za-z][A-Za-z\s&'\-]+?)\s+(\d+):(\d+)(?:\s*[-–]\s*(\d+))?$",
        reference.strip(), re.IGNORECASE
    )
    if not m:
        return {"found": False, "error": f"Could not parse reference: **{reference}**\nTry: `John 3:16 DRB`", "suggestions": []}

    book_raw = m.group(1).strip()
    chapter  = m.group(2)
    verse_s  = int(m.group(3))
    verse_e  = int(m.group(4)) if m.group(4) else verse_s

    # Resolve book name: check DR aliases first, then KJV→DR map, then direct match
    key = book_raw.lower()
    dr_book = _DR_USER_ALIASES.get(key)
    if dr_book is None:
        # Try KJV canonical name (title-cased)
        for kjv_name, drb_name in _KJV_TO_DR.items():
            if key == kjv_name.lower():
                dr_book = drb_name
                break
    if dr_book is None:
        # Try direct match against DR book names (e.g. "John", "Genesis")
        for drb_name in data.keys():
            if key == drb_name.lower():
                dr_book = drb_name
                break

    if dr_book is None:
        # Special case: KJV 1/2 Esdras are NOT in DR
        if key in ("1 esdras", "2 esdras") and "1 Esdras" not in data:
            return {"found": False,
                    "error": f"**1-2 Esdras** in the KJV Apocrypha are not present in the Douay-Rheims. "
                             f"DR uses **1 Esdras** = Ezra and **2 Esdras** = Nehemiah.",
                    "suggestions": ["1 Esdras DRB", "2 Esdras DRB"]}
        return {"found": False,
                "error": f"Book **{book_raw}** not found in the Douay-Rheims Bible.",
                "suggestions": []}

    chap_data = data.get(dr_book, {}).get(str(chapter))
    if chap_data is None:
        max_ch = max((int(k) for k in data[dr_book].keys()), default=0)
        return {"found": False,
                "error": f"**{dr_book}** has no chapter {chapter}. (Max: {max_ch})",
                "suggestions": []}

    # Collect verses
    texts = []
    for v in range(verse_s, verse_e + 1):
        t = chap_data.get(str(v))
        if t:
            # Strip italics markers (* used for supplied words in DR)
            t = t.replace("*", "")
            texts.append(t.strip())

    if not texts:
        max_v = max((int(k) for k in chap_data.keys()), default=0)
        return {"found": False,
                "error": f"**{dr_book} {chapter}** has no verse {verse_s}. (Max: {max_v})",
                "suggestions": []}

    ref_label = f"{dr_book} {chapter}:{verse_s}" + (f"–{verse_e}" if verse_e != verse_s else "")
    text = " ".join(texts)

    return {
        "found":     True,
        "reference": ref_label,
        "text":      text,
        "source":    "Douay-Rheims Bible (Challoner revision)",
        "book":      dr_book,
        "chapter":   int(chapter),
        "verse":     verse_s,
    }
